﻿#MaxThreads 255
#Requires AutoHotkey v2.0
#SingleInstance Force

;libs
ShowLoading(10, "2.5s", "Loading Libraries")
#Include "%A_ScriptDir%\library"
#Include "Gdip_All.ahk"
#Include "Gdip_ImageSearch.ahk"
#Include "Functions.ahk"
#Include "%A_ScriptDir%\library\mscorrection.ahk"
#Include "%A_ScriptDir%\library\_JXON.ahk"
#Include "%A_ScriptDir%\library\bitmaps.ahk"
#Include "%A_ScriptDir%\library\Class_CNG.ahk"
#Include "%A_ScriptDir%\library\ColorButton.ahk"
#Include "%A_ScriptDir%\library\Sockets.ahk"
;#Include "%A_ScriptDir%\library\HoneyDetection.ahk"
ShowLoading(40, "2.0s", "Initializing Settings")

#Warn VarUnset, Off
OnError (e, mode) => (mode = "Return") ? -1 : 0

SetWorkingDir A_ScriptDir
CoordMode "Mouse", "Screen"
CoordMode "Pixel", "Screen"
CoordMode "ToolTip", "Screen"
SendMode "Event"

Token := BotToken := "MTM2MzYxODk3MTQ2MjY2ODMyOQ.G6gOLm.05jUnktci-wCNniUnjrVhR9w07Yh2-3EYDTOto", LastMessageID := "", Messages := "", ids := "", PremiumVer := 0, debugging := 0, Verified := 0
CloseMiscScripts()
if !debugging ;testing
	ShowLoading(60, "1.2s", "Verify License"), Verified := 1

ShowLoading(75, "1.0s", "Preparing Network")
StartSocketConnection()
ShowLoading(100, "0.0s")

if A_ScreenDPI != 96
{
    MsgBox(
        "Your display scaling is not set to 100% (96 DPI)." 
        . "`n`nThis script is designed to run at 100% scaling and may not work correctly."
        . "`n`nPlease set Windows display scaling to 100% and restart the script.",
        "Display Scaling Warning",
        "Icon!"
    )
}

Init()
bitmaps := bmpInit(A_ScriptDir "\images")
bitmaps.CaseSense := 0
SetTrayMenu()
MacroHotkeys("Off")
MainGui := Gui("+Border +OwnDialogs +border +minsize50x30", "Boost Macro")
MainGui.OnEvent("Close", GetOut)
MainGui.SetFont("s9 cDefault norm")

MainGui.Add("Button", "x5 y232 w60 h20 -Wrap vStartButton", "Start (" StartHotkey ")").OnEvent("Click", StartMacro).SetRounded()
MainGui.Add("Button", "x70 y232 w60 h20 -Wrap vPauseButton", "Pause (" PauseHotkey ")").OnEvent("Click", PauseMacro).SetRounded()
MainGui.Add("Button", "x135 y232 w60 h20 -Wrap vReloadButton", "Stop (" ReloadHotkey ")").OnEvent("Click", ReloadMacro).SetRounded()
MainGui.Add("Button", "x200 y232 w60 h20 -Wrap", "Discord").OnEvent("Click", (*) => GetServerInvite("", "1363618686233088302")).SetRounded()
MainGui.Add("Text", "x285 y235 w200 vStatus", "Status: Idle").Focus()

(TabCtrl := MainGui.Add("Tab", "x0 y-1 w500 h270 -Wrap", ["Main", "Settings"])).OnEvent("Change", (*) => TabCtrl.Focus())
hTab := TabCtrl.Hwnd
SendMessage(0x1331, 0, 99, , hTab)

TabCtrl.UseTab("Main")
MainGui.SetFont("s9 cDefault norm w500")
MainGui.Add("GroupBox", "x10 y25 w205 h200", "Hotbars")

HotBars := []

Loop 7
{
    idx := A_Index

    HotBars.Push(Map())
    HotBars[idx]["Time"] := IniRead("config.ini", "settings", "HotBarTime" idx, "0")
    HotBars[idx]["OnStar"] := IniRead("config.ini", "settings", "HotBarOnStar" idx, "0")
	HotBars[idx]["Started"] := 0

    MainGui.Add("Text", "x15 y" (25 + idx * 25), "Hotbar " idx " (s):")

    MainGui.Add("Edit", "x85 y" (22 + idx * 25) " w50 vHotBarTime" idx).OnEvent("Change", SaveChangeSettings)

    MainGui.Add("CheckBox", "x145 y" (26 + idx * 25) " r1 w54 vHotBarOnStar" idx, "On Star").OnEvent("Click", SaveChangeSettings)

    MainGui["HotBarTime" idx].Text := HotBars[idx]["Time"]
    MainGui["HotBarOnStar" idx].Value := HotBars[idx]["OnStar"]
}


MainGui.Add("GroupBox", "x230 y25 w260 h68", "During Star")
;clip stars
MainGui.Add("Text", "x240 y45", "Clip Stars:")
MainGui.Add("CheckBox", "x292 y47 w15 r1 vClipStars " (ClipStars ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x243 y60", "\__")
MainGui.Add("Text", "x270 y65", "Hotkey:")
MainGui.Add("HotKey", "x320 y63 w35 h20 vClipHotkey " (!ClipStars ? " Disabled" : ""), "None").OnEvent("Change", SaveChangeSettings)
MainGui["ClipHotkey"].value := ClipHotkey

;star honey
MainGui.Add("Text", "x370 y45", "Detect Star Honey:")
MainGui.Add("CheckBox", "x470 y47 w15 r1 vDetectStarHoney disabled unchecked" (DetectStarHoney ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x373 y60", "\__")
MainGui.Add("Text", "x400 y65", "Log To File:")
MainGui.Add("CheckBox", "x470 y67 w15 r1 vLogHoneyPerStar disabled unchecked" (LogHoneyPerStar ? "Checked" : "") (!DetectStarHoney ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)

;buff tracker
MainGui.Add("GroupBox", "x230 y100 w260 h126", "Buff Tracker")
MainGui.Add("Button", "x440 y99 w17 h17 vPrevPage", "<").OnEvent("Click", NewPage)
MainGui.Add("Button", "x460 y99 w17 h17 vNextPage", ">").OnEvent("Click", NewPage)

;precision
MainGui.Add("Text", "x235 y122 vPrecisionTrackerText", "Precision Tracker:")
MainGui.Add("CheckBox", "x337 y122 w15 r1 vTrackPrecision " (TrackPrecision ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x238 y137 vPrecisionNoiseText1", "\__")
MainGui.Add("Text", "x265 y142 vPrecisionNoiseText2", "Make Noise:")
MainGui.Add("CheckBox", "x337 y142 w15 r1 vTrackPrecisionBeep " (TrackPrecisionBeep ? "Checked" : "") (!TrackPrecision ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)

;4x
MainGui.Add("Text", "x370 y122 vBoostsTrackerText", "4x Boost Tracker:")
MainGui.Add("CheckBox", "x470 y122 w15 r1 vTrackBoosts disabled " (TrackBoosts ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x375 y137 vBoostsNoiseText1", "\__")
MainGui.Add("Text", "x402 y142 vBoostsNoiseText2", "Make Noise:")
MainGui.Add("CheckBox", "x470 y142 w15 r1 vTrackBoostsBeep disabled " (TrackBoostsBeep ? "Checked" : "") (!TrackBoosts ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)

;gummy morph
MainGui.Add("Text", "x235 y180 vGMorphTrackerText", "GMorph Tracker:")
MainGui.Add("CheckBox", "x337 y180 w15 r1 vTrackGMorph " (TrackGMorph ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x238 y195 vGMorphNoiseText1", "\__")
MainGui.Add("Text", "x265 y200 vGMorphNoiseText2", "Make Noise:")
MainGui.Add("CheckBox", "x337 y200 w15 r1 vTrackGMorphBeep " (TrackGMorphBeep ? "Checked" : "") (!TrackGMorph ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)

;smoothie
MainGui.Add("Text", "x370 y180 vSmoothieTrackerText", "Smoothie Tracker:")
MainGui.Add("CheckBox", "x470 y180 w15 r1 vTrackSmoothie " (TrackSmoothie ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x375 y195 vSmoothieNoiseText1", "\__")
MainGui.Add("Text", "x402 y200 vSmoothieNoiseText2", "Make Noise:")
MainGui.Add("CheckBox", "x470 y200 w15 r1 vTrackSmoothieBeep " (TrackSmoothieBeep ? "Checked" : "") (!TrackSmoothie ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)

;Next Page
;guiding
MainGui.Add("Text", "x235 y122 vGuidingTrackerText", "Guiding Tracker:").visible := 0
MainGui.Add("CheckBox", "x337 y122 w15 r1 vTrackGuiding " (TrackGuiding ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x238 y137 vGuidingCountDownText1", "\__").visible := 0
MainGui.Add("Text", "x265 y142 vGuidingCountDownText2", "CountDown:").visible := 0
MainGui.Add("CheckBox", "x337 y142 w15 r1 vTrackGuidingCountDown " (TrackGuidingCountDown ? "Checked" : "") (!TrackGuiding ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)
MainGui["TrackGuiding"].visible := 0, MainGui["TrackGuidingCountDown"].visible := 0

;precise marks
MainGui.Add("Text", "x235 y180 vPMarkTrackerText", "PMark Tracker:").visible := 0
MainGui.Add("CheckBox", "x337 y180 w15 r1 vTrackPMark " (TrackPMark ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x238 y195 vPMarkNoiseText1", "\__").visible := 0
MainGui.Add("Text", "x265 y200 vPMarkNoiseText2", "Make Noise:").visible := 0
MainGui.Add("CheckBox", "x337 y200 w15 r1 vTrackPMarkBeep " (TrackPMarkBeep ? "Checked" : "") (!TrackPMark ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)
MainGui["TrackPMark"].visible := 0, MainGui["TrackPMarkBeep"].visible := 0

;gummy tracker
MainGui.Add("Text", "x370 y122 vGummyStarTrackerText", "Gummy Tracker:").visible := 0
MainGui.Add("CheckBox", "x470 y122 w15 r1 vTrackGummyStar " (TrackGummyStar ? "Checked" : "")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("Text", "x375 y137 vGummyStarCountdownText1", "\__").visible := 0
MainGui.Add("Text", "x402 y142 vGummyStarCountdownText2", "CountDown:").visible := 0
MainGui.Add("CheckBox", "x470 y142 w15 r1 vTrackGummyStarCountDown " (TrackGummyStarCountDown ? "Checked" : "") (!TrackGummyStar ? " Disabled" : "")).OnEvent("Click", SaveChangeSettings)
MainGui["TrackGummyStar"].visible := 0, MainGui["TrackGummyStarCountDown"].visible := 0

TabCtrl.UseTab("Settings")
MainGui.SetFont("s9 cDefault norm w500")
MainGui.Add("GroupBox", "x10 y25 w170 h110", "Star Detection")
MainGui.Add("Text", "x18 y50", "Detect Gummy Star:")
MainGui.Add("Text", "x18 y80", "Detect Scorching Star:")
MainGui.Add("Text", "x18 y110", "Detect Pop Star:")
MainGui.Add("CheckBox", "x155 y52 w13 r1 vDetectGummyStar " (DetectGummyStar && "Checked")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("CheckBox", "x155 y82 w13 r1 vDetectScorchingStar " (DetectScorchingStar && "Checked")).OnEvent("Click", SaveChangeSettings)
MainGui.Add("CheckBox", "x155 y112 w13 r1 vDetectPopStar " (DetectPopStar && "Checked")).OnEvent("Click", SaveChangeSettings)

maingui.Add("GroupBox", "x190 y25 w300 h110", "Account Status Monitor")
accountLV := maingui.Add("ListView", "x200 y42 w285 h85 -Multi -0x200 +NoSort +ReadOnly -LV0x10 +LV0x10000 +0x2000", ["     Connection", "Status", "Alt Role"])
LV_NoSizing(accountLV)
accountLV.ModifyCol(1, "95")
accountLV.ModifyCol(2, "95 Center")
accountLV.ModifyCol(3, "95 Center")

ip := GetLocalIP(), port := RegExReplace(SocketServer.addr, "^.*:", "")
MainGui.Add("GroupBox", "x190 y138 w300 h87", "Server available at:")
MainGui.Add("Edit", "x200 y164 w150 vipBox ReadOnly", ip ":" port)
MainGui.Add("Button", "x210 y190 w60 vCopy", "Copy").OnEvent("Click", (*) => ShowFollowTip("Copied to clipboard", 1))

MainGui.Add("GroupBox", "x10 y138 w170 h87", "Hotkeys")
MainGui.Add("Button", "x125 y135 h20", "Reset").OnEvent("Click", ResetHotkeys)
MainGui.Add("Text", "x18 y157", "Start Script:")
MainGui.Add("Text", "x18 y181", "Pause Script:")
MainGui.Add("Text", "x18 y205", "Reload Script:")
MainGui.Add("Hotkey", "x116 y156 w60 h18 vStartHotkey", StartHotkey).OnEvent("Change", SaveChangeSettings)
MainGui.Add("Hotkey", "x116 y178 w60 h18 vPauseHotkey", PauseHotkey).OnEvent("Change", SaveChangeSettings)
MainGui.Add("Hotkey", "x116 y202 w60 h18 vReloadHotkey", ReloadHotkey).OnEvent("Change", SaveChangeSettings)

MainGui.Show("x" MainGuiXValue " y" MainGuiYValue " w500 h260")
UpdateMacroStatus((SocketServer.GetLastError() = 0 ? "Status: Started Server" : "Status: Connecting To Server..."))
MacroHotkeys("On")
Return

StartMacro(*)
{
    global
	if (CheckWarnings() || Started || !Verified)
		Return

	Started := 1, Stopped := 0, Reloading := 0
	exe64_Path := A_WorkingDir "\AutoHotkey.exe"
	Run('"' exe64_Path '" /script "' A_WorkingDir '\library\DetectBuffs.ahk" "' TrackPrecision '" "' TrackPrecisionBeep '" "' TrackGMorph '" "' TrackGMorphBeep '" "' TrackBoosts '" "' TrackBoostsBeep '" "' TrackSmoothie '" "' TrackSmoothieBeep '" "' TrackGuiding '" "' TrackGuidingCountDown '" "' TrackPMark '" "' TrackPMarkBeep '" "' TrackGummyStar '" "' TrackGummyStarCountDown '"')
	OpenRoblox()
	StartHotBarTimers()
	StarDetection(HotBars)
	Return
}

PauseMacro(*)
{
	global
	if (!Started || !Verified)
		Return

	Paused := !A_IsPaused
	if WinExist("Buff Detector")
		try PostMessage(0x5558)

	DetectHiddenWindows 1
	if WinExist("HotBarUser.ahk ahk_class AutoHotkey")
		try PostMessage(0x5558)
	
	DetectHiddenWindows 0
    Pause -1
	Return
}

ReloadMacro(*)
{
	global
	if !Verified
		Return

	Reloading := 1, Started := 0, Stopped := 1
	if Paused
	{
		Pause -1
		Paused := 0
	}
	GetGUIPos()
	CloseMiscScripts()
	UI(1)
	Reloading := 0
	Return
}