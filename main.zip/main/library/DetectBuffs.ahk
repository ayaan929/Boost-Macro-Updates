#MaxThreads 255
#Requires AutoHotkey v2.0
#SingleInstance Force

#Include "%A_ScriptDir%\..\library"
#Include "Gdip_All.ahk"
#Include "Gdip_ImageSearch.ahk"

;#Warn VarUnset, Off
OnError (e, mode) => (mode = "Return") ? -1 : 0

SetWorkingDir A_ScriptDir
CoordMode "Mouse", "Screen"
CoordMode "Pixel", "Screen"
SendMode "Event"

OnMessage(0x5558, PauseScript)

if A_ScreenDPI != 96
{
    MsgBox(
        "Your display scaling is not set to 100% (96 DPI)." 
        . "`n`nThis script is designed to run at 100% scaling and may not work correctly."
        . "`n`nPlease set Windows display scaling to 100% and restart the script.",
        "Display Scaling Warning",
        "Icon!"
    )
}

if !(A_Args.Length > 0) {
   MsgBox("You Must Run:`n`n" A_ScriptDir "\Main.ahk`n`nIn order to run this!!!", , 48)
   ExitApp
   Return
}

TrackPrecision := A_Args[1]
TrackPrecisionBeep := A_Args[2]
TrackGMorph := A_Args[3]
TrackGMorphBeep := A_Args[4]
TrackBoosts := A_Args[5]
TrackBoostsBeep := A_Args[6]
TrackSmoothie := A_Args[7]
TrackSmoothieBeep := A_Args[8]
TrackGuiding := A_Args[9]
TrackGuidingCountDown := A_Args[10]
TrackPMark := A_Args[11]
TrackPMarkBeep := A_Args[12]
TrackGummyStar := A_Args[13]
TrackGummyStarCountDown := A_Args[14]

BuffTrackerList := [TrackPrecision, TrackGMorph, TrackBoosts, TrackSmoothie, TrackGuiding, TrackPMark, TrackGummyStar]
for k, v in BuffTrackerList
{
	if v = 1
		Break
	
	if A_Index = BuffTrackerList.Length
		ExitApp
}

GetOut(*)
{
	try Gdip_Shutdown(pToken)
	ExitApp
}
init()
{
    global

	GuidingSeconds := 0, LastPMarkAnnounce := 0, YChange := 0, LastPrecisionBeep := 0, LastGStar := 0, GumdropsUsed := 1

    pToken := Gdip_Startup()

	(bmp := Map()).CaseSense := 0
	bmp["Pollen"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAC8AAAASCAYAAADLw4ffAAAAAXNSR0IArs4c6QAAAFtJREFUSEtjZBjCgHEIu51h+DheSFT8Pywm3r1+Oeg9huLAIe/4oRDisNSBEfKjjqdTETa80vyQLm1G0/xApHk62Uk1awZ9LYrPp6OOp1o6INGg0ZAnMcCophwAMrskE17dtboAAAAASUVORK5CYII=")
	bmp["E"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAB8AAAAnCAYAAAD3h5P5AAAAAXNSR0IArs4c6QAAAIVJREFUWEftlkEOABEUQ7mkyZxQuOTMbhYstDQhmVpX67//iRg2rrgxO5wVnu7rmaVRc6GK6cQOn0Evx84aMoce9tzhDE5Ua+wfqfaR8cChQ8ToPHBnDhzTQ/ZmDHv+n3Cm0lUt9edaDWv3O1xNFPIzdgiTWmTsaqKQn7FDmNQiY1cThfxehApMKLrJaW4AAAAASUVORK5CYII=")
	bmp["MakeHoney"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABkAAAAOAQMAAADg9CUDAAAABlBMVEUAAAD3//lCqWtQAAAAAXRSTlMAQObYZgAAAFFJREFUeAEBRgC5/wDgAAOAAOAAA4AA4AADgADh/4OAAOB/g4AA4H4DgADgPgOAAOAYA4AA4BgDgADgGAOAAOAYA4AA4AgDgADgAAOAAOAAA4BWYxcOMd0SeAAAAABJRU5ErkJggg==")
	BMP["Make"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAADoAAAAWCAYAAACR1Y9lAAAA60lEQVR4AeySSw7DIAxEm26q3v+wVVep3sLIIEMgVE5IiDQC7PFn7DwfN/mm0Kstem50bnTQCYRf97N+VzCojs22g9BN5k4CwwO58JIvF6PtxKfQfrlHQt/LaxHHv05yApqpzVnLhUfuFFadSKhFOMJG4z11GUAaf0qhVqNp47xbBuImtKUpRLSAwWhYtSKhkFsK5LjksZDjp3ar0ZSj3/A1tE/ukVAx9p66qNx7c/bGB6FHNUTdvSL4a2pjg9DagDPxWoY0tFAZOpsF8rZON6Hl6Vut1dvIDUoRbkJLTXj4plCPKXvWuM1GfwAAAP//eT6cHQAAAAZJREFUAwCFpHQtvBg4XAAAAABJRU5ErkJggg==")
	bmp["MobHealthBar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAAXNSR0IArs4c6QAAABNJREFUGFdjlH/u8p8BD2AkpAAA1XYElV55JcEAAAAASUVORK5CYII=")
	bmp["PlanterBar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAYAAAABCAYAAAD9yd/wAAAAAXNSR0IArs4c6QAAABBJREFUGFdjbLta8J8BCwAAPnACzF4pj08AAAAASUVORK5CYII=")
	bmp["ClaimHive"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAADMAAAAUCAMAAAFg0cUAAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAGUExURff/+QAAAJz6Ds8AAAACdFJOU/8A5bcwSgAAAAlwSFlzAAAOwgAADsIBFShKgAAAAGNJREFUKFPtj9sKgDAMQ+3//7TNZbYbok8KgoexLEk32BaBlVDzZA2QTmqBujlzMnnEcwN35tbZVspQ2EqIsseq3iAEw0jJRcPto82UzRMd/r1wShZbaPTAKVls0Yr/zlt3InZhnwMqg6pSYgAAAABJRU5ErkJggg==")
	bmp["HiveDay1"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAUAAAABCAYAAAAW/mTzAAAAD0lEQVR4AWI60sr0Hx0DAAAA//+SEZDZAAAABklEQVQDAHf5C3U5BOdsAAAAAElFTkSuQmCC")
	bmp["HiveDay2"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAcAAAABCAYAAAASC7TOAAAAE0lEQVR4AWLaWs30HxveUs30HwAAAP//RsaTnwAAAAZJREFUAwDdXw9ZkJOWOAAAAABJRU5ErkJggg==")
	bmp["HiveDay3"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAcAAAABCAYAAAASC7TOAAAAD0lEQVR4AWLqjmP4jwsDAAAA//8k/iXcAAAABklEQVQDAL5aDVtj8w+QAAAAAElFTkSuQmCC")
	bmp["HiveNight1"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAUAAAABCAYAAAAW/mTzAAAAD0lEQVR4AWJaUczwHx0DAAAA//8Eso4EAAAABklEQVQDAG0nCoUlEYvwAAAAAElFTkSuQmCC")
	bmp["HiveNight2"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABYAAAABCAYAAADaZ14YAAAAGklEQVR4AbTDQREAAAABQaO0YAKS4h7rRiMcAAD//78BpcsAAAAGSURBVAMAP58viW4df70AAAAASUVORK5CYII=")
	bmp["HiveNight3"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAsAAAABCAYAAAAIN1RAAAAAF0lEQVR4AWJaXcLwf00pDlzG8H8tEgYAAAD//y00MNQAAAAGSURBVAMAC6QXaPn4dC8AAAAASUVORK5CYII=")
	bmp["InvOpen"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAAS0lEQVR4AZSNsQkAIAwE1REUXECwcv9JrAS3EFNGvvhGEEzgeALJfXCfYz/scyhYshXcRXYjDVvEAe5Mu7GV6kGOyQOamHYjP195AAAA//973Z06AAAABklEQVQDAHznFhOjAEZmAAAAAElFTkSuQmCC")
	bmp["CloseBee"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABkAAAAdCAYAAABfeMd1AAAAp0lEQVR4AeyR0QmAMBBD1XFcwG8n99sFXEfJR0COpqQtCMIJJfbq5dXcMn3wJKQp5Izrp3Gt236rq9fO2GMN/jqPWZnhjGZKLQiaYaZAOK8tGwITgKBcLrQJQnNqhLIedQgSzdS+C+LGRGgXhM2udkHcWfASXRA2u9oEibOIewW1ITCMMcX9MEQZAq7MWbf/hA1RFfz93TDkbabeE6KSKdYzrmIsqvgAAAD//1sgrfIAAAAGSURBVAMAfbMoOwR5FOgAAAAASUVORK5CYII=")
	bmp["CPU"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABsAAAAUCAYAAAB8gkaAAAAAdklEQVR4AeySwQ7AIAhDx/7/m+eAgwdBbcR4MJBs0Qp9sfF9DlbCtoSdMV4eY+Fqr8hSabXeHn4gYkpcPSNENzAxRQZXehzYt+IDzRgYkZGqkXdrTpZqw2RhnEfDo7MJR48NTFXnFwWJJQyT5uiXsGiCOn80xh8AAP//x56QUAAAAAZJREFUAwDCihcpwbXPTwAAAABJRU5ErkJggg==")
	bmp["Mem"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAACQAAAAPCAYAAACMa21tAAABqklEQVR4AbSVPUsDQRCGd/Mj0mhtJWgnWKbwA4Ogv8HGMtiZyq9CEezt/AMWFgo2FoKFjSJWIlFQEUHUQIx3ucuN++4xsiS7d5c7DJnM3Mw7O082y6a0uLVHaTazUqeRiUkarUxRtb5J47PzNDY9R9XVDZ1DDZq0dVz17aUysZVEhpffaolOux0riUS344vQ9wVFkRAkdA2aWFDsMxOQ1/zUEBgOCMCEnhcDqSQAoSmGEndnAvppfokoCHSHBtI7pIDUbiGJGjSIi5oV6LBek6ZdnxzJl8a9vD07lcc7axK7E/qeiMJQkILqhoHofLeKsuh+KxAqapA6HYj67eHmSuJMtT/eRaDOFqmzBMh+5eAZJ5BUr6TlXh8b8vxgX95dXsi35yftzV3tjZPWMmtOoKQdMhdwxb39AHRpzbwTyBTZYgxk4zqeOc7rcwOpX/TvnXe4rc8JhGm2hv/OOYF4MK57jtO8+SXMOK3PrFuBAMEGMccL67tUWa5ReWhYG2LkuG5qOWd61NPMCuRq0veNuhC5jssROX7GcI7z+sGB1H8YD8NlaAJxvoj/BQAA//8G1w0kAAAABklEQVQDAGSnSQNmo+UpAAAAAElFTkSuQmCC")
	bmp["ShiftLockOn"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAACQAAAAiCAYAAAA3WXuFAAABWUlEQVR4AeyTi27CMAxFAW3sL7dv2/5ygIAeRCUrdZyb1EIIgXTJy745dtvd5sl+b6DWA3mdDu3/zhf0dR+Zt6pXzqUO7X9Pl9Ls8L3bov/7yLyMGVk3gaj88POxHTEnh3xGVSEQZmsrJx+f1UCYYKYaRXH44BfFzGfVDmEyB2WMqp8LpFYzg35OX9o8j0bF1wVSqrEQx+lLs+salOLrAtUM7T4Q5VqBsjnefAgo42IPhr0hoLI7GKHaPmeqhoCseXa3VgNldMUWuACKPs2MbkT+gC2AlE+TxEgReMt/ARRd9IizLiD1fVHjvAK7gKwBj8XKnq2Zu0CtF48L6YIVexlygXjxFKgMgNLDBSIoG0otsAqUCQUMBeLZUghEsmpErKceGPKbQASNCBDyegtSgPC9iUtK3Q6mP7s/LTe9IOSgLiAuKYUJsvusR9UFNHpJT94bqNWtp+vQFQAA//8aM7bnAAAABklEQVQDAJnSsEUaVD+5AAAAAElFTkSuQmCC")
	bmp["ScorchingStar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAwAAAABCAYAAADq6085AAAANklEQVR4ARzDWwpAERRA0et6JLPBMf8Z+VFKYZOP9a8SWOKZYi/NFgXyPTMrRtb0ZGjJUqPjAAAA//+0Plr8AAAABklEQVQDAIi5GkcMlR7NAAAAAElFTkSuQmCC")
	bmp["GummyStar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAwAAAABCAYAAADq6085AAAAPUlEQVR4AQAxAM7/As6L2f/Pi9n/z4zZ/86O2f/Bm9j/oa/S/3LKyv9Q4MX/PuvA/z3swP897MD/Peu//wAAAP//tCFh9AAAAAZJREFUAwCPpiS46v82yQAAAABJRU5ErkJggg==")
	bmp["Precision"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAsAAAABCAYAAAAIN1RAAAAAD0lEQVR4AWLq99vyn1gMAAAA//82TngtAAAABklEQVQDAHF0HDNvvlBQAAAAAElFTkSuQmCC")
	bmp["Smoothie"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABgAAAABBAMAAAA2gHOYAAAAMFBMVEVKRDlKRTlYTjpjVjtvXjh1YDV2YTV5YzeNcjmkgzywiz3PokTotUr0vk36w0/+xlDRVtQJAAAAGElEQVR4AQENAPL/AP7JcxAAAAACRWir3x4xBISoIvpcAAAAAElFTkSuQmCC")
	bmp["DarkHeat"] := Gdip_CreateBitmap(1, 1), G := Gdip_GraphicsFromImage(bmp["DarkHeat"]), Gdip_GraphicsClear(G, 0xFFDB0812), Gdip_DeleteGraphics(G)
	bmp["PreciseMark"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAJUlEQVR4AWKaY/Pjf7/lg/8RBvX/tTS0wThEv/J/r+W9/yA5AAAAAP//QN4Y8AAAAAZJREFUAwAfNRHkaAYOrQAAAABJRU5ErkJggg==")
	bmp["GummyStar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAALUlEQVR4AQAhAN7/AumT9f/rlff/6Zr2/9qh8v+ztOj/itTd/27p1f9i8NL/AAAA//+1XMneAAAABklEQVQDALxaGqN/HzmjAAAAAElFTkSuQmCC")
	bmp["GummyStarTop"] := Gdip_CreateBitmap(5, 1), G := Gdip_GraphicsFromImage(bmp["GummyStarTop"]), Gdip_GraphicsClear(G, 0xFFCDB4C0), Gdip_DeleteGraphics(G)
	
	characters := Map()
	characters[2] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAQAAAALCAAAAAB9zHN3AAAAAnRSTlMAAHaTzTgAAABCSURBVHgBATcAyP8BAPMAAADzAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPMAAADzAAAA8wAAAPMAAAAB8wAAAAIAAAAAtc8GqohTl5oAAAAASUVORK5CYII=")
	characters[3] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAQAAAAKCAAAAAC2kKDSAAAAAnRSTlMAAHaTzTgAAAA9SURBVHgBATIAzf8BAPMAAAAAAAAAAAAAAAAAAAAAAAAAAADzAAAAAAAAAAAAAAAAAAAAAPMAAAABAPMAAFILA8/B68+8AAAAAElFTkSuQmCC")

	TrackMap := Map(
		"TrackPrecision", 	{ Enabled: TrackPrecision, Color: "Purple", Label: "Precision", Var: "Precision", InitialValue: (TrackPrecision ? "0s" : "Disabled") },
		"TrackGMorph",    	{ Enabled: TrackGMorph,    Color: "CC66CC",  Label: "GMorph", Var: "GMorph", InitialValue: (TrackGMorph ? "0x" : "Disabled") },
		"TrackSmoothie",  	{ Enabled: TrackSmoothie,  Color: "Green", Label: "Smoothie", Var: "SmoothieT", InitialValue: ((TrackSmoothie ? "Inactive" : "Disabled")) },
		"TrackPMark",    	{ Enabled: TrackPMark,    Color: "red", Label: "PMarks", Var: "CurrentPMarks", InitialValue: "0x" },
		"TrackGuiding",    	{ Enabled: TrackGuiding,    Color: "Olive", Label: "Guiding", Var: "Guiding", InitialValue: "00:00" },
		"TrackGummyStar",    { Enabled: TrackGummyStar,    Color: "CC66CC", Label: "GStar", Var: "GStar", InitialValue: "0/75" }
	)

	BuffArray := []
	for name, data in TrackMap
	{
		if data.Enabled
		{
			BuffArray.Push({
				Name:  name,
				Label: data.Label,
				Color: data.Color,
				Var: data.Var,
				InitialValue: data.InitialValue
			})
		}
	}

    Return
}

init(), GetRobloxClientPos()

BuffGui := Gui("+Border +OwnDialogs +MinimizeBox -MaximizeBox +MinSize50x30 +E0x08040000 +LastFound +AlwaysOnTop", "Buff Detector")
BuffGui.OnEvent("Close", GetOut)
BuffGui.SetFont("cDefault norm s12", "Tahoma")

yPos := 15
for _, buff in BuffArray
{
    BuffGui.Add("Text", "x12 y" yPos " +BackgroundTrans c" buff.Color, buff.Label ":")
    BuffGui.Add("Text", "x134 y" yPos " +BackgroundTrans w200 r1 v" buff.Var " c" buff.Color, buff.InitialValue)
	yPos += 35
}

BuffGui.Show("x" windowX+windowWidth-210 " y" windowy+20 " w200 h" yPos)

OpenRoblox(), (TrackGummyStar && SetTimer(TrackGStar, 2100))

loop
{
	YChange := (YChange < 21 ? GetYChange() : YChange)
	TrackBuffs()
	Sleep(1500)
}

PauseScript(*)
{
	global
	Pause -1
}

TrackGStar(*)
{
	global
	GetRobloxClientPos()

	if (A_TickCount - LastGStar < 60500)
	{
		BuffGui["GStar"].text := "Active (" (A_TickCount - LastGStar)/1000 "s)"
		Return
	}

	pBMRegion := Gdip_BitmapFromScreen(WindowX "|" WindowY+windowHeight-150 "|" windowWidth "|" 50)
	star := (Gdip_ImageSearch(pBMRegion, bmp["GummyStar"],,,,,, 15) = 0)
	Gdip_DisposeImage(pBMRegion)

	if (GumdropsUsed >= 75 || star)
	{
		GumdropsUsed := 1, LastGStar := A_TickCount
		pBMRegion := Gdip_BitmapFromScreen(windowX "|" windowY+YChange+40 "|" windowWidth "|" 40)
		if Gdip_ImageSearch(pBMRegion, bmp["GummyStarTop"],,,,,,4) = 1
		{
			BuffGui["GStar"].text := "Active (60s)"
			Gdip_DisposeImage(pBMRegion)
			Return
		}

		Gdip_DisposeImage(pBMRegion)
	}

	GumdropsUsed++
	BuffGui["GStar"].text := GumdropsUsed "/75"
}

TrackBuffs()
{
	global
	if TrackPrecision
	{
		PrecisionTime := GetPrecisionTime()
		if PrecisionTime <= 20
			(TrackPrecisionBeep && speak("Precision", 70, 3, "Precision")), BuffGui["Precision"].text := "Refresh!"

		else
			BuffGui["Precision"].text := PrecisionTime "s"
	}

	if TrackGMorph
	{
		GMorphTime := GetGummyMorph()
		if !GMorphTime
			(TrackGMorphBeep && speak("Gummy Morph", 50, 4, "GMorph"))

		BuffGui["GMorph"].text := (!GMorphTime ? "Active" : GMorphTime)
	}

	if TrackSmoothie
	{
		Smoothie := GetSmoothieTime()
		if !Smoothie
			(TrackSmoothieBeep && speak("Smoothie", 50, 4, "Smoothie")), BuffGui["SmoothieT"].text := "Inactive"

		else
			BuffGui["SmoothieT"].text := "Active"
	}

	if TrackPMark
	{
		ActivePmarks := GetActivePreciseMarks()
		if (ActivePmarks = 3 && TrackPMarkBeep && (nowUnix()-LastPMarkAnnounce > 44))
			speak("3x PMarks", 50, 4, "PMark"), LastPMarkAnnounce := nowUnix()

		BuffGui["CurrentPMarks"].Text := ActivePmarks "x"
	}

	if TrackGuiding
		GetGuidingTime()
}

;funcs
GetActivePreciseMarks()
{
	global

	GetRobloxClientPos()
	PMarks := 0

	pBMRegion := Gdip_BitmapFromScreen(windowX "|" windowY+YChange+40 "|" windowWidth "|" 40)
	PreciseMarkActive := Gdip_ImageSearch(pBMRegion, bmp["PreciseMark"],&list,,,,,6)

	if PreciseMarkActive
	{
		x := SubStr(list, 1, InStr(list, ",")-1), y := SubStr(list, InStr(list, ",")+1)
		pBMPreciseRegion := Gdip_BitmapFromScreen(WindowX+x-14 "|" windowY+YChange+38 "|" 38 "|" 38)
		Loop 3
		{
			if (Gdip_ImageSearch(pBMPreciseRegion, characters[4-A_Index],,,,,,2) = 1)
			{
				PMarks := 4-A_Index
				Break
			}

			if A_Index = 3
				PMarks := 1
		}

		Gdip_DisposeImage(pBMPreciseRegion)
	}
	
	Gdip_DisposeImage(pBMRegion)
	Return PMarks
}

GetPrecisionTime()
{
	global
	
	GetRobloxClientPos()
	Time := 0, TimeLeft := 0
	chdc := CreateCompatibleDC(), hbm := CreateDIBSection(windowWidth, 38, chdc), obm := SelectObject(chdc, hbm), hhdc := GetDC()
	BitBlt(chdc, 0, 0, windowWidth, 38, hhdc, windowX, windowY+YChange+37)
	ReleaseDC(hhdc)
	pBMArea := Gdip_CreateBitmapFromHBITMAP(hbm)
	SelectObject(chdc, obm), DeleteObject(hbm), DeleteDC(hhdc), DeleteDC(chdc)

	x := 0

	loop 2 ;precision and dark heat
	{
		if (Gdip_ImageSearch(pBMArea, bmp["Precision"], &list, x, 14, , , , , 6) = 1)
		{
			x := SubStr(list, 1, InStr(list, ",")-1), y := SubStr(list, InStr(list, ",")+1)
			if (Gdip_ImageSearch(pBMArea, bmp["DarkHeat"], , x+2, , x+Max(16, 2*y-24), y, 6) = 0) ;confirm it isnt dark heat
			{
				if (PixelSearch(&OutputVarX, &OutputVarY, windowX+x-14, windowY+YChange+y, windowX+x+24, WindowY+96, 0x8F4EB4, 0) = 1)
					Time := OutputVarY-WindowY+YChange

				TimeLeft := (Time = 0 ? 0 : (n:=Round(((96+YChange-Time)/60)*100)) > 60 ? 60 : n-(n > 20 ? 2 : 1))
				Break
			}
		}

		x += 2*y-14
	}

	Gdip_DisposeImage(pBMArea)
	Return TimeLeft
}

GetGummyMorph()
{
    GetRobloxClientPos()
    
    loop 29
    {
        if (ImageSearch(&FoundX, &FoundY, WindowX, WindowY+windowHeight-150, windowX+windowWidth, WindowY+windowHeight-50, "*30 " A_ScriptDir "\..\images\gummy" A_Index ".png") = 1)
			Return A_Index
    }

	Return 0
}

GetGuidingTime()
{
	global

	if (!GuidingSeconds || nowUnix() - GuidingSeconds > 600)
	{
		if (ImageSearch(&FoundX, &FoundY, WindowX, windowY+YChange+30, windowX+windowWidth, windowY+YChange+80, "*30 " A_ScriptDir "\..\images\Guiding.png") = 1)
		{
			GuidingSeconds := nowUnix()
			if TrackGuidingCountDown
				SetTimer(GuidingCountdown, 1000)

			else
				BuffGui["Guiding"].text := "Active"
		}

		else
			GuidingSeconds := 0, BuffGui["Guiding"].text := "Inactive"
	}
}
GetSmoothieTime()
{
	global

	pBMRegion := Gdip_BitmapFromScreen(windowX "|" windowY+YChange+40 "|" windowWidth "|" 40)
	Smoothie := Gdip_ImageSearch(pBMRegion, bmp["Smoothie"],,,,,,2)
	Gdip_DisposeImage(pBMRegion)
	
	Return Smoothie
}
GuidingCountdown()
{
	global GuidingSeconds, BuffGui
	GuidingTimeGone := nowUnix() - GuidingSeconds

	if (GuidingTimeGone > 600)
	{
		SetTimer(GuidingCountdown, 0), BuffGui["Guiding"].text := "00:00", GuidingActive := 0, GuidingTimeGone := 0, GuidingSeconds := 0
		Return
	}
	
	TimeLeft := 600-GuidingTimeGone
	Mins := TimeLeft//60
	Secs := Mod(TimeLeft, 60)

	BuffGui["Guiding"].text := "0" Mins ":" Secs
}
speak(text, volume := 100, rate := 0, buff:="")
{
	BuffText := IniRead(A_ScriptDir "\..\config.ini", "settings", buff "Sound")

	if BuffText = "Default"
	{
		try
		{
			tts := ComObject("SAPI.SpVoice")
			tts.Volume := IniRead(A_ScriptDir "\..\config.ini", "settings", buff "Vol")
			tts.Rate := IniRead(A_ScriptDir "\..\config.ini", "settings", buff "Rate")
			tts.Speak(IniRead(A_ScriptDir "\..\config.ini", "settings", buff "Text"))
		}
	}

	else
		SoundPlay(BuffText, "*-1")
}
;roblox funcs
GetRobloxClientPos(hwnd?)
{
	global windowX, windowY, windowWidth, windowHeight
	if !IsSet(hwnd)
		hwnd := GetRobloxHWND()

	try
		WinGetClientPos &windowX, &windowY, &windowWidth, &windowHeight, "ahk_id " hwnd
	catch TargetError
		return windowX := windowY := windowWidth := windowHeight := 0
	else
		return 1
}

; Returns: hWnd = successful; 0 = window not found
GetRobloxHWND()
{
	if (hwnd := WinExist("Roblox ahk_exe RobloxPlayerBeta.exe"))
		return hwnd
	else if (WinExist("Roblox ahk_exe ApplicationFrameHost.exe"))
	{
		try
			hwnd := ControlGetHwnd("ApplicationFrameInputSinkWindow1")
		catch TargetError
			hwnd := 0
		return hwnd
	}

	else
		return 0
}

OpenRoblox(GetOffset:=0)
{
	Robloxhwnd := GetRobloxHWND()

	try WinActivate Robloxhwnd

	if GetOffset
	{
		sleep(500)
		GetRobloxClientPos(), YChange := GetYChange()
	}
}

CloseRoblox()
{
	; if roblox exists, activate it and send Esc+L+Enter
	if (hwnd := GetRobloxHWND())
	{
		GetRobloxClientPos(hwnd)
		if (windowHeight >= 500) ; requirement for L to activate "Leave"
		{
			WinActivate "Roblox"
			SetKeyDelay 250
			send "{Esc}{L}{Enter}"
		}
		SetKeyDelay 20
		try WinClose "Roblox"
		Sleep 500
		try WinClose "Roblox"
		Sleep 4500 ;Delay to prevent Roblox Error Code 264
	}
	; kill any remnant processes
	for p in ComObjGet("winmgmts:").ExecQuery("SELECT * FROM Win32_Process WHERE Name LIKE '%Roblox%' OR CommandLine LIKE '%ROBLOXCORPORATION%'")
		ProcessClose p.ProcessID
}

Roblox()
{
	n := "Roblox ahk_exe ApplicationFrameHost.exe"
	if WinExist(n)
		return n
	n := "Roblox ahk_exe RobloxPlayerBeta.exe"
	if WinExist(n)
		return n
	return 0
}

OpenRobloxChat() => (Send("{/}"), Sleep(50), Send("{Enter}"), Sleep(100))

GetYChange()
{
	GetRobloxClientPos()
	Y := 0

	loop 3
	{
		pBMRegion := Gdip_BitmapFromScreen(windowX+windowWidth//2 "|" windowY "|100|100")
		if (Gdip_ImageSearch(pBMRegion, bmp["Pollen"],&out,,,,,2) = 1)
		{
			SplitArray := StrSplit(out, ",")
			if SplitArray.Length > 0
			{
				Y := (SplitArray[2]+4)-15
				Gdip_DisposeImage(pBMRegion)
				Break
			}
		}
		Gdip_DisposeImage(pBMRegion)
	}
	Return (Y <= 0 ? 0 : Y)
}

nowUnix() => DateDiff(A_NowUTC, "19700101000000", "Seconds")