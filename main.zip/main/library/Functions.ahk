﻿;startup
CloseMiscScripts()
{
	DetectHiddenWindows 1
	scripts := WinGetList("ahk_class AutoHotkey")

	if scripts.Length {
		for hwnd in scripts {
			title := WinGetTitle(hwnd)
			if (InStr(title, "*") || InStr(title, "DetectBuffs") || InStr(title, "HotBarUser"))
				try WinClose("ahk_id " hwnd)
		}
	}

	DetectHiddenWindows 0
}
GetServerInvite(Token, ChannelId)
{
    return ""
}

DiscordRequest(method, url, token, body := "") {
    try {
        req := ComObject("WinHttp.WinHttpRequest.5.1")
        req.Open(method, url, false)
        req.SetRequestHeader("User-Agent", "DiscordBot (AHK, " A_AhkVersion ")")
        req.SetRequestHeader("Authorization", "Bot " token)
        req.SetRequestHeader("Content-Type", "application/json")
        
        if (body != "") {
            req.Send(body)
        } else {
            req.Send()
        }
        
        if (req.Status >= 400) {
            return ""
        }
        
        return req.ResponseText
        
    } catch {
        return ""
    }
}

WmiQuery(Query, Field)
{
    col := ComObject("winmgmts:").ExecQuery(Query)
    enum := col._NewEnum()
    item := unset
    while enum[item]
        return item.%Field%
    return ""
}

;ui
NewPage(ctrl, info)
{
	BuffUiFirstPageName := [
		"TrackPrecision", "TrackPrecisionBeep", "PrecisionTrackerText", "PrecisionNoiseText1", "PrecisionNoiseText2",
		"TrackBoosts", "TrackBoostsBeep", "BoostsTrackerText", "BoostsNoiseText1", "BoostsNoiseText2",
		"TrackGMorph", "TrackGMorphBeep", "GMorphTrackerText", "GMorphNoiseText1", "GMorphNoiseText2",
		"TrackSmoothie", "TrackSmoothieBeep", "SmoothieTrackerText", "SmoothieNoiseText1", "SmoothieNoiseText2",
	]

	BuffUiNextPageName := [
		"TrackGuiding", "GuidingTrackerText", "GuidingCountDownText1", "GuidingCountDownText2", "TrackGuidingCountDown",
		"PMarkTrackerText", "TrackPMark", "PMarkNoiseText1", "PMarkNoiseText2", "TrackPMarkBeep",
		"GummyStarTrackerText", "TrackGummyStar", "GummyStarCountdownText1", "GummyStarCountdownText2", "TrackGummyStarCountDown"
	]

	for k, v in BuffUiFirstPageName
		MainGui[v].visible := (ctrl.name = "NextPage" ? 0 : 1)

	for k, v in BuffUiNextPageName
		MainGui[v].visible := (ctrl.name = "NextPage" ? 1 : 0)
}
LV_NoSizing(hListView)
{
	static LVM_FIRST     := 0x1000
	static LVM_GETHEADER := LVM_FIRST + 31
	static HDS_NOSIZING  := 0x0800

	hListViewHeader := SendMessage(LVM_GETHEADER, 0, 0, hListView)
	ControlSetStyle("+" . HDS_NOSIZING, hListViewHeader)
}
MacroHotkeys(mode)
{
    global StartHotkey, PauseHotkey, ReloadHotkey

    hkStart  := "~*" StartHotkey
    hkPause  := "~*" PauseHotkey
    hkReload := "~*" ReloadHotkey

    Hotkey hkStart, StartMacro,  mode
    Hotkey hkPause, PauseMacro,  mode
    Hotkey hkReload, ReloadMacro, mode
}
ShowFollowTip(text, Clipboard:=0)
{
    static followTimer, clearTimer

	if Clipboard
		A_Clipboard := MainGui["ipBox"].Text

    if followTimer
        SetTimer(followTimer, 0)
    if clearTimer
        SetTimer(clearTimer, 0)

    followTimer := (p*) => UpdateFollowTip(text)
    clearTimer  := (p*) => ClearFollowTip(followTimer)

    SetTimer(followTimer, 20)
    SetTimer(clearTimer, -2000)

	Return 1
}

UpdateFollowTip(text)
{
    MouseGetPos(&mx, &my)
    ToolTip(text, mx + 10, my + 10)

	Return 1
}

ClearFollowTip(followTimer)
{
    SetTimer(followTimer, 0)
    ToolTip()

	Return 1
}
ShowLoading(percent:=0, timeLeft:="", Message:="")
{
    global LoadingGui, LoadingBar, LoadingText, LoadingTime, GuiLoadstart

    if !IsSet(LoadingGui) {
		GuiLoadstart := A_TickCount
        LoadingGui := Gui("-ToolWindow -Caption")
        LoadingGui.BackColor := "202020"
        LoadingGui.SetFont("s10 cFFFFFF Bold")

        LoadingText := LoadingGui.Add("Text", "x10 y8 w180 Center", Message "... 0%")
        LoadingBar  := LoadingGui.Add("Progress", "x10 y32 w180 h12 cGreen Background404040", percent)
        LoadingTime := LoadingGui.Add("Text", "x10 y52 w180 Center", "Time Left: --")

        LoadingGui.Show("w200 h80 Center")
    }

	if (A_TickCount - GuiLoadstart > 60000)
	{
		MsgBox("An Error Has Occured`n`nTry Reloading",, "T5"), LoadingGui.Destroy()
		ExitApp
		return
	}

    LoadingText.Value := Message "... " percent "%"
    LoadingBar.Value  := percent
    LoadingTime.Value := "Time Left: " timeLeft

    if percent >= 100 {
        LoadingGui.Destroy()
        LoadingGui := ""
    }
}
GetGUIPos()
{
	global MainGuiXValue, MainGuiYValue
	wp := Buffer(44)
	DllCall("GetWindowPlacement", "UInt", MainGui.Hwnd, "Ptr", wp)
	x := NumGet(wp, 28, "Int"), y := NumGet(wp, 32, "Int")
	if (x > 0)
		try IniWrite x, "config.ini", "Settings", "MainGuiXValue"
	if (y > 0)
		try IniWrite y, "config.ini", "Settings", "MainGuiYValue"
}
SetTrayMenu()
{
	A_TrayMenu.Add()
	A_TrayMenu.Add("Start Script", StartMacro)
	A_TrayMenu.Add("Pause Script", PauseMacro)
	A_TrayMenu.Add("Reload Script", ReloadMacro)
	A_TrayMenu.Default := "Start Script"
}
UpdateListView(name, status, role)
{
	global Accounts
	Critical

	if !IsObject(Accounts) || Type(Accounts) != "Array"
    	Accounts := []

	for k, v in Accounts ;acc already added
	{
		if v = name
		{
			accountLV.Modify(A_Index, "", name, status, role)
			Return 1
		}
	}

	accountLV.Add("", name, status, role)
	Accounts.Push(name)
}
CreateSettingsFolder()
{
	global
	defaults := Map()

	defaults := Map("MoveSpeedNum", 29
		, "HotBarOnStar1", "0"
		, "HotBarOnStar2", "0"
		, "HotBarOnStar3", "0"
		, "HotBarOnStar4", "0"
		, "HotBarOnStar5", "0"
		, "HotBarOnStar6", "0"
		, "HotBarOnStar7", "0"
		, "HotBarTime1", "0"
		, "HotBarTime2", "0"
		, "HotBarTime3", "0"
		, "HotBarTime4", "0"
		, "HotBarTime5", "0"
		, "HotBarTime6", "0"
		, "HotBarTime7", "0"
		, "ClipStars", "0"
		, "ClipHotkey", "None"
		, "DetectStarHoney", "0"
		, "LogHoneyPerStar", "0"
		, "TrackPrecision", "0"
		, "TrackPrecisionBeep", "0"
		, "TrackBoosts", "0"
		, "TrackBoostsBeep", "0"
		, "TrackGMorph", "0"
		, "TrackGMorphBeep", "0"
		, "TrackSmoothie", "0"
		, "TrackSmoothieBeep", "0"
		, "DetectGummyStar", "1"
		, "DetectScorchingStar", "0"
		, "DetectPopStar", "0"
		, "StartHotkey", "F1"
		, "PauseHotkey", "F2"
		, "ReloadHotkey", "F3"
		, "PrecisionVol", "50"
		, "PrecisionRate", "3"
		, "PrecisionText", "Precision"
		, "PrecisionSound", "Default"
		, "GMorphVol", "50"
		, "GMorphRate", "3"
		, "GMorphText", "Gummy Morph"
		, "GMorphSound", "Default"
		, "SmoothieVol", "50"
		, "SmoothieRate", "3"
		, "SmoothieText", "Smoothie"
		, "SmoothieSound", "Default"
		, "TrackGuiding", "0"
		, "TrackGuidingCountDown", "0"
		, "TrackPMark", "0"
		, "TrackPMarkBeep", "0"
		, "PMarkSound", "Default"
		, "TrackGummyStar", "0"
		, "TrackGummyStarCountDown", "0"
		, "MainGuiXValue", A_ScreenWidth//2
		, "MainGuiYValue", A_ScreenHeight//2)

	for k, v in defaults
       	IniWrite(v, "config.ini", "settings", k)
}
Init()
{
	global

	MacroHotkeys("Off")
	(!FileExist("config.ini") || !IniRead("config.ini", "settings")) && CreateSettingsFolder()
	Accounts := [], Started := 0
	HiveConfirmed := 0, ToggleGumdrops := 1, Started := 0, StartedHB1 := 0, StartedHB2 := 0, StartedHB3 := 0, StartedHB4 := 0, StartedHB5 := 0, StartedHB6 := 0, StartedHB7 := 0
	HotBarOnStar1 := IniRead("config.ini", "settings", "HotBarOnStar1"), HotBarOnStar2 := IniRead("config.ini", "settings", "HotBarOnStar2"), HotBarOnStar3 := IniRead("config.ini", "settings", "HotBarOnStar3"), HotBarOnStar4 := IniRead("config.ini", "settings", "HotBarOnStar4"), HotBarOnStar5 := IniRead("config.ini", "settings", "HotBarOnStar5"), HotBarOnStar6 := IniRead("config.ini", "settings", "HotBarOnStar6"), HotBarOnStar7 := IniRead("config.ini", "settings", "HotBarOnStar7")
	HotBarTime1 := IniRead("config.ini", "settings", "HotBarTime1"), HotBarTime2 := IniRead("config.ini", "settings", "HotBarTime2"), HotBarTime3 := IniRead("config.ini", "settings", "HotBarTime3"), HotBarTime4 := IniRead("config.ini", "settings", "HotBarTime4"), HotBarTime5 := IniRead("config.ini", "settings", "HotBarTime5"), HotBarTime6 := IniRead("config.ini", "settings", "HotBarTime6"), HotBarTime7 := IniRead("config.ini", "settings", "HotBarTime7")
	ClipStars := IniRead("config.ini", "settings", "ClipStars")
	ClipHotkey := IniRead("config.ini", "settings", "ClipHotkey")
	MoveSpeedNum := IniRead("config.ini", "settings", "MoveSpeedNum")
	Vip := IniRead("config.ini", "settings", "Vip")
	Gumdrops := IniRead("config.ini", "settings", "Gumdrops")
	AlignDrops := IniRead("config.ini", "settings", "AlignDrops")
	FileDir := IniRead("config.ini", "settings", "FileDir")
	HiveSlot := IniRead("config.ini", "settings", "HiveSlot")
	Field := IniRead("config.ini", "settings", "Field")
	AltRole := IniRead("config.ini", "settings", "AltRole")
	Pattern := IniRead("config.ini", "settings", "Pattern")
	MovementType := IniRead("config.ini", "settings", "MovementType")
	SatAlignType := IniRead("config.ini", "settings", "SatAlignType")
	MainGuiXValue := IniRead("config.ini", "settings", "MainGuiXValue"), ((MainGuiXValue <= 0 || MainGuiXValue = "" || MainGuiXValue > A_ScreenWidth-75) && MainGuiXValue := A_ScreenWidth//2)
	MainGuiYValue := IniRead("config.ini", "settings", "MainGuiYValue"), ((MainGuiYValue <= 0 || MainGuiYValue = "" || MainGuiYValue > A_ScreenHeight-75) && MainGuiYValue := A_ScreenHeight//2)
	DetectGummyStar := IniRead("config.ini", "settings", "DetectGummyStar")
	DetectScorchingStar := IniRead("config.ini", "settings", "DetectScorchingStar")
	DetectPopStar := IniRead("config.ini", "settings", "DetectPopStar")
	TrackPrecision := IniRead("config.ini", "settings", "TrackPrecision")
	TrackPrecisionBeep := IniRead("config.ini", "settings", "TrackPrecisionBeep")
	TrackGMorph := IniRead("config.ini", "settings", "TrackGMorph")
	TrackGMorphBeep := IniRead("config.ini", "settings", "TrackGMorphBeep")
	TrackBoosts := IniRead("config.ini", "settings", "TrackBoosts")
	TrackBoostsBeep := IniRead("config.ini", "settings", "TrackBoostsBeep")
	TrackSmoothie := IniRead("config.ini", "settings", "TrackSmoothie")
	TrackSmoothieBeep := IniRead("config.ini", "settings", "TrackSmoothieBeep")
	DetectStarHoney := IniRead("config.ini", "settings", "DetectStarHoney")
	LogHoneyPerStar := IniRead("config.ini", "settings", "LogHoneyPerStar")
	TrackGuiding := IniRead("config.ini", "settings", "TrackGuiding")
	TrackGuidingCountDown := IniRead("config.ini", "settings", "TrackGuidingCountDown")
	TrackPMark := IniRead("config.ini", "settings", "TrackPMark")
	TrackPMarkBeep := IniRead("config.ini", "settings", "TrackPMarkBeep")
	TrackGummyStar := IniRead("config.ini", "settings", "TrackGummyStar")
	TrackGummyStarCountDown := IniRead("config.ini", "settings", "TrackGummyStarCountDown")
	StartHotkey := IniRead("config.ini", "settings", "StartHotkey"), ((StartHotkey = "" || StartHotkey = "None" || !StartHotkey) && StartHotkey := "F1")
	PauseHotkey := IniRead("config.ini", "settings", "PauseHotkey"), ((PauseHotkey = "" || PauseHotkey = "None" || !PauseHotkey) && PauseHotkey := "F2")
	ReloadHotkey := IniRead("config.ini", "settings", "ReloadHotkey"), ((ReloadHotkey = "" || ReloadHotkey = "None" || !ReloadHotkey) && ReloadHotkey := "F3")

	;gdip
	pToken := Gdip_Startup()

	(bmp := Map()).CaseSense := 0
	bmp["Pollen"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAC8AAAASCAYAAADLw4ffAAAAAXNSR0IArs4c6QAAAFtJREFUSEtjZBjCgHEIu51h+DheSFT8Pywm3r1+Oeg9huLAIe/4oRDisNSBEfKjjqdTETa80vyQLm1G0/xApHk62Uk1awZ9LYrPp6OOp1o6INGg0ZAnMcCophwAMrskE17dtboAAAAASUVORK5CYII=")
	bmp["E"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAB8AAAAnCAYAAAD3h5P5AAAAAXNSR0IArs4c6QAAAIVJREFUWEftlkEOABEUQ7mkyZxQuOTMbhYstDQhmVpX67//iRg2rrgxO5wVnu7rmaVRc6GK6cQOn0Evx84aMoce9tzhDE5Ua+wfqfaR8cChQ8ToPHBnDhzTQ/ZmDHv+n3Cm0lUt9edaDWv3O1xNFPIzdgiTWmTsaqKQn7FDmNQiY1cThfxehApMKLrJaW4AAAAASUVORK5CYII=")
	bmp["MakeHoney"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABkAAAAOAQMAAADg9CUDAAAABlBMVEUAAAD3//lCqWtQAAAAAXRSTlMAQObYZgAAAFFJREFUeAEBRgC5/wDgAAOAAOAAA4AA4AADgADh/4OAAOB/g4AA4H4DgADgPgOAAOAYA4AA4BgDgADgGAOAAOAYA4AA4AgDgADgAAOAAOAAA4BWYxcOMd0SeAAAAABJRU5ErkJggg==")
	BMP["Make"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAADoAAAAWCAYAAACR1Y9lAAAA60lEQVR4AeySSw7DIAxEm26q3v+wVVep3sLIIEMgVE5IiDQC7PFn7DwfN/mm0Kstem50bnTQCYRf97N+VzCojs22g9BN5k4CwwO58JIvF6PtxKfQfrlHQt/LaxHHv05yApqpzVnLhUfuFFadSKhFOMJG4z11GUAaf0qhVqNp47xbBuImtKUpRLSAwWhYtSKhkFsK5LjksZDjp3ar0ZSj3/A1tE/ukVAx9p66qNx7c/bGB6FHNUTdvSL4a2pjg9DagDPxWoY0tFAZOpsF8rZON6Hl6Vut1dvIDUoRbkJLTXj4plCPKXvWuM1GfwAAAP//eT6cHQAAAAZJREFUAwCFpHQtvBg4XAAAAABJRU5ErkJggg==")
	bmp["MobHealthBar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAAXNSR0IArs4c6QAAABNJREFUGFdjlH/u8p8BD2AkpAAA1XYElV55JcEAAAAASUVORK5CYII=")
	bmp["PlanterBar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAYAAAABCAYAAAD9yd/wAAAAAXNSR0IArs4c6QAAABBJREFUGFdjbLta8J8BCwAAPnACzF4pj08AAAAASUVORK5CYII=")
	bmp["ClaimHive"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAADMAAAAUCAMAAAFg0cUAAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAGUExURff/+QAAAJz6Ds8AAAACdFJOU/8A5bcwSgAAAAlwSFlzAAAOwgAADsIBFShKgAAAAGNJREFUKFPtj9sKgDAMQ+3//7TNZbYbok8KgoexLEk32BaBlVDzZA2QTmqBujlzMnnEcwN35tbZVspQ2EqIsseq3iAEw0jJRcPto82UzRMd/r1wShZbaPTAKVls0Yr/zlt3InZhnwMqg6pSYgAAAABJRU5ErkJggg==")
	bmp["HiveDay1"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAUAAAABCAYAAAAW/mTzAAAAD0lEQVR4AWI60sr0Hx0DAAAA//+SEZDZAAAABklEQVQDAHf5C3U5BOdsAAAAAElFTkSuQmCC")
	bmp["HiveDay2"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAcAAAABCAYAAAASC7TOAAAAE0lEQVR4AWLaWs30HxveUs30HwAAAP//RsaTnwAAAAZJREFUAwDdXw9ZkJOWOAAAAABJRU5ErkJggg==")
	bmp["HiveDay3"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAcAAAABCAYAAAASC7TOAAAAD0lEQVR4AWLqjmP4jwsDAAAA//8k/iXcAAAABklEQVQDAL5aDVtj8w+QAAAAAElFTkSuQmCC")
	bmp["HiveNight1"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAUAAAABCAYAAAAW/mTzAAAAD0lEQVR4AWJaUczwHx0DAAAA//8Eso4EAAAABklEQVQDAG0nCoUlEYvwAAAAAElFTkSuQmCC")
	bmp["HiveNight2"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABYAAAABCAYAAADaZ14YAAAAGklEQVR4AbTDQREAAAABQaO0YAKS4h7rRiMcAAD//78BpcsAAAAGSURBVAMAP58viW4df70AAAAASUVORK5CYII=")
	bmp["HiveNight3"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAsAAAABCAYAAAAIN1RAAAAAF0lEQVR4AWJaXcLwf00pDlzG8H8tEgYAAAD//y00MNQAAAAGSURBVAMAC6QXaPn4dC8AAAAASUVORK5CYII=")
	bmp["InvOpen"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAAS0lEQVR4AZSNsQkAIAwE1REUXECwcv9JrAS3EFNGvvhGEEzgeALJfXCfYz/scyhYshXcRXYjDVvEAe5Mu7GV6kGOyQOamHYjP195AAAA//973Z06AAAABklEQVQDAHznFhOjAEZmAAAAAElFTkSuQmCC")
	bmp["CloseBee"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABkAAAAdCAYAAABfeMd1AAAAp0lEQVR4AeyR0QmAMBBD1XFcwG8n99sFXEfJR0COpqQtCMIJJfbq5dXcMn3wJKQp5Izrp3Gt236rq9fO2GMN/jqPWZnhjGZKLQiaYaZAOK8tGwITgKBcLrQJQnNqhLIedQgSzdS+C+LGRGgXhM2udkHcWfASXRA2u9oEibOIewW1ITCMMcX9MEQZAq7MWbf/hA1RFfz93TDkbabeE6KSKdYzrmIsqvgAAAD//1sgrfIAAAAGSURBVAMAfbMoOwR5FOgAAAAASUVORK5CYII=")
	bmp["CPU"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAABsAAAAUCAYAAAB8gkaAAAAAdklEQVR4AeySwQ7AIAhDx/7/m+eAgwdBbcR4MJBs0Qp9sfF9DlbCtoSdMV4eY+Fqr8hSabXeHn4gYkpcPSNENzAxRQZXehzYt+IDzRgYkZGqkXdrTpZqw2RhnEfDo7MJR48NTFXnFwWJJQyT5uiXsGiCOn80xh8AAP//x56QUAAAAAZJREFUAwDCihcpwbXPTwAAAABJRU5ErkJggg==")
	bmp["Mem"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAACQAAAAPCAYAAACMa21tAAABqklEQVR4AbSVPUsDQRCGd/Mj0mhtJWgnWKbwA4Ogv8HGMtiZyq9CEezt/AMWFgo2FoKFjSJWIlFQEUHUQIx3ucuN++4xsiS7d5c7DJnM3Mw7O082y6a0uLVHaTazUqeRiUkarUxRtb5J47PzNDY9R9XVDZ1DDZq0dVz17aUysZVEhpffaolOux0riUS344vQ9wVFkRAkdA2aWFDsMxOQ1/zUEBgOCMCEnhcDqSQAoSmGEndnAvppfokoCHSHBtI7pIDUbiGJGjSIi5oV6LBek6ZdnxzJl8a9vD07lcc7axK7E/qeiMJQkILqhoHofLeKsuh+KxAqapA6HYj67eHmSuJMtT/eRaDOFqmzBMh+5eAZJ5BUr6TlXh8b8vxgX95dXsi35yftzV3tjZPWMmtOoKQdMhdwxb39AHRpzbwTyBTZYgxk4zqeOc7rcwOpX/TvnXe4rc8JhGm2hv/OOYF4MK57jtO8+SXMOK3PrFuBAMEGMccL67tUWa5ReWhYG2LkuG5qOWd61NPMCuRq0veNuhC5jssROX7GcI7z+sGB1H8YD8NlaAJxvoj/BQAA//8G1w0kAAAABklEQVQDAGSnSQNmo+UpAAAAAElFTkSuQmCC")
	bmp["ShiftLockOn"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAACQAAAAiCAYAAAA3WXuFAAABWUlEQVR4AeyTi27CMAxFAW3sL7dv2/5ygIAeRCUrdZyb1EIIgXTJy745dtvd5sl+b6DWA3mdDu3/zhf0dR+Zt6pXzqUO7X9Pl9Ls8L3bov/7yLyMGVk3gaj88POxHTEnh3xGVSEQZmsrJx+f1UCYYKYaRXH44BfFzGfVDmEyB2WMqp8LpFYzg35OX9o8j0bF1wVSqrEQx+lLs+salOLrAtUM7T4Q5VqBsjnefAgo42IPhr0hoLI7GKHaPmeqhoCseXa3VgNldMUWuACKPs2MbkT+gC2AlE+TxEgReMt/ARRd9IizLiD1fVHjvAK7gKwBj8XKnq2Zu0CtF48L6YIVexlygXjxFKgMgNLDBSIoG0otsAqUCQUMBeLZUghEsmpErKceGPKbQASNCBDyegtSgPC9iUtK3Q6mP7s/LTe9IOSgLiAuKYUJsvusR9UFNHpJT94bqNWtp+vQFQAA//8aM7bnAAAABklEQVQDAJnSsEUaVD+5AAAAAElFTkSuQmCC")
	bmp["GummyStar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAwAAAABCAYAAADq6085AAAAPUlEQVR4AQAxAM7/As6L2f/Pi9n/z4zZ/86O2f/Bm9j/oa/S/3LKyv9Q4MX/PuvA/z3swP897MD/Peu//wAAAP//tCFh9AAAAAZJREFUAwCPpiS46v82yQAAAABJRU5ErkJggg==")
	bmp["Precision"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAIklEQVR4AWLq99vyH4TbPFf+T7Ws+9/ovuh/r+9GsBhIHAAAAP//ArZSzwAAAAZJREFUAwA+dBPIAT4vYAAAAABJRU5ErkJggg==")
	bmp["GummyStar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAALUlEQVR4AQAhAN7/AumT9f/rlff/6Zr2/9qh8v+ztOj/itTd/27p1f9i8NL/AAAA//+1XMneAAAABklEQVQDALxaGqN/HzmjAAAAAElFTkSuQmCC")
	bmp["ScorchingStar"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAAXNSR0IArs4c6QAAABVJREFUGFdjZIACxlfGLP/Fzv5hBAASrQQDTFUrdwAAAABJRU5ErkJggg==")
	bmp["ComboStrawberry"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAB8AAAAHCAYAAADwK5bPAAAAbElEQVR4AbSQ0QnAIAxE2wzSLTpGp+0Y3aKLKE8IHPkIKiocJrmcZ2LPfZUjOfDAWzT2Wu8dtfZ+/5mJ4UHWM8vZrLBXp9PqENS3m6uhfpj6EnOm0IdjHHnPmzmJIop35c2cFShGzdCOauivAAAA//+mjjv5AAAABklEQVQDAA7xMOyUQZ0aAAAAAElFTkSuQmCC")
	bmp["ComboIcon"] := Gdip_BitmapFromBase64("iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAAZ0lEQVR4AXTMwQ2AIAyFYXAuN/Du0asTOIUTePXo3Q3cC/M3eaSUQPICbT86pXCu5y0ktFMHBcBEdQf3dckacgsbPLe50BwFbBDgMVsJfaVCNfztcQPZSiLmQwM9iG+Dx/1lEoe+/gEAAP//I4w7OAAAAAZJREFUAwARZyRbHg7v6wAAAABJRU5ErkJggg==")

	;keys
	YChange := GetYChange()
	MoveUp := "SC011"
	MoveLeft := "SC01E"
	MoveDown := "SC01F"
	MoveRight := "SC020"
	TurnLeft := "SC033"
	TurnRight := "SC034"
	Space := "SC039"
	e := "SC012"

	movespeed := MoveSpeedNum
    both            := (Mod(movespeed*1000, 1265) = 0) || (Mod(Round((movespeed+0.005)*1000), 1265) = 0)
    hasty_guard     := (both || Mod(movespeed*1000, 1100) < 0.00001)
    gifted_hasty    := (both || Mod(movespeed*1000, 1150) < 0.00001)
    base_movespeed  := round(movespeed / (both ? 1.265 : (hasty_guard ? 1.1 : (gifted_hasty ? 1.15 : 1))), 0)

	files := Map(), Fields := Map(), Patterns := Map()
	Version := "v1.1.0", Reloading := 0, Stopped := 0, Paused := 0

	GetPaths()
	GetPatterns()
}
SetWarnings()
{
	global

	if (MoveSpeedNum < 10 || MoveSpeedNum > 50)
		MsgBox("Inalid MoveSpeed!`n`nMake Sure You Set The Correct Move Speed From In Game BSS Without Any Speed Buffs",, "48 T5")

	if Vip != "" && !InStr(Vip, "https://www.roblox.com/gameas/1537690962/Bee-Swarm-Simulator?privateServerLinkCode=") && !InStr(Vip, "https://www.roblox.com/games/1537690962?privateServerLinkCode=")
		MsgBox("Invalid Vip Link!`n`nIt must start with:`nhttps://www.roblox.com/games/1537690962/Bee-Swarm-Simulator?privateServerLinkCode=",, "48 T5")

	if (!FileExist(FileDir) && FileDir != "")
		MsgBox("Invalid File Directory!`n`nMake Sure This Directory Exists And That All RDP's Can Acces It",, "48 T5")
}
GetPaths()
{
	global
	
	for k, v in ["pepper", "rose", "spider"]
	{
		Loop Files A_ScriptDir "\Imported\Paths\" v "\*.ahk"
		{
			fileName := A_LoopFileName
			fileContent := FileRead(A_LoopFileFullPath)
			Fields[fileName] := fileContent
		}
	}
}
GetPatterns()
{
	global

	PatternPath := A_ScriptDir "\Imported\patterns"
	PList := []
	Loop Files PatternPath "\*.ahk"
	{
		fileName := A_LoopFileName
		fileContent := FileRead(A_LoopFileFullPath)
		Patterns[fileName] := fileContent
		PList.Push(StrReplace(fileName, ".ahk"))
	}
}

SetSpeedVars()
{
	global MoveSpeedNum

	movespeed := MoveSpeedNum
	both            := (Mod(movespeed*1000, 1265) = 0) || (Mod(Round((movespeed+0.005)*1000), 1265) = 0)
	hasty_guard     := (both || Mod(movespeed*1000, 1100) < 0.00001)
	gifted_hasty    := (both || Mod(movespeed*1000, 1150) < 0.00001)
	base_movespeed  := round(movespeed / (both ? 1.265 : (hasty_guard ? 1.1 : (gifted_hasty ? 1.15 : 1))), 0)
}

SaveSettings(ctrl, info)
{
	global
	
	%ctrl.Name% := ctrl.text

	IniWrite(ctrl.text, "config.ini", "settings", ctrl.Name)
}
SaveChangeSettings(ctrl, info)
{
	global

	if ((InStr(ctrl.Name, "Track") && InStr(ctrl.Name, "Beep") && (ctrl.value = 1)))
	{
		ShowSliderTooltip(slider, Option)
		{
			IniWrite(slider.value, "config.ini", "settings", ChosenBuff Option)
			ToolTip(slider.Value)
			SetTimer(hideTooltip, -1000)
		}

		speak(text, volume := 100, rate := 0)
		{
			Text := IniRead("config.ini", "settings", ChosenBuff "Sound")

			if Text = "Default"
			{
				try
				{
					tts := ComObject("SAPI.SpVoice")
					tts.Volume := IniRead("config.ini", "settings", ChosenBuff "Vol")
					tts.Rate := IniRead("config.ini", "settings", ChosenBuff "Rate")
					tts.Speak(IniRead("config.ini", "settings", ChosenBuff "Text"))
				}
			}

			else
				SoundPlay(Text, "*-1")
		}

		SelectFolder(*)
		{
			FileSelected := FileSelect(, A_ScriptDir "\sounds")
			if FileSelected
			{
				TTSgui["Sound"].text := FileSelected
				IniWrite(FileSelected, "config.ini", "settings", ChosenBuff "Sound")
				TTSgui["Volume"].enabled := 0
				TTSgui["Rate"].enabled := 0
				TTSgui["SoundText"].enabled := 0
			}
		}

		SetDefaultSound(*)
		{
			global

			TTSgui["Sound"].Text := "Default"
			TTSgui["Volume"].value := 50
			TTSgui["Rate"].value := 3
			TTSgui["SoundText"].value := ChosenBuff
			TTSgui["Volume"].enabled := 1
			TTSgui["Rate"].enabled := 1
			TTSgui["SoundText"].enabled := 1
			IniWrite("Default", "config.ini", "settings", ChosenBuff "Sound")
			IniWrite("50", "config.ini", "settings", ChosenBuff "Vol")
			IniWrite("3", "config.ini", "settings", ChosenBuff "Rate")
			IniWrite(ChosenBuff, "config.ini", "settings", ChosenBuff "Text")
		}

		ChangeSound(*)
		{
			global

			IniWrite(TTSgui["Sound"].Text, "config.ini", "settings", ChosenBuff "Sound")
			DefaultSettings := (TTSgui["Sound"].Text = "Default")
			TTSgui["Volume"].enabled := DefaultSettings
			TTSgui["Rate"].enabled := DefaultSettings
			TTSgui["SoundText"].enabled := DefaultSettings
		}

		ChosenBuff := StrReplace(StrReplace(ctrl.Name, "Track"), "Beep")
		TTSgui := gui("+AlwaysOnTop", "Sound Control - " ChosenBuff)
		TTSgui.AddText("x10 y10", "Sound:")
		Voice := TTSgui.AddEdit("x78 y8 w175 r1 vSound", IniRead("config.ini", "settings", ChosenBuff "Sound", "Default")).OnEvent("Change", ChangeSound)
		TTSgui.Add("Button", "x256 y8 vFileSelect", "File Names").OnEvent("Click", SelectFolder)
		TTSgui.AddText("x10 y45", "Volume:")
		sliderVol := TTSgui.AddSlider("x70 y42 w260 vVolume Range0-100 TickInterval10", IniRead("config.ini", "settings", ChosenBuff "Vol"))
		TTSgui.AddText("x10 y80", "Rate:")
		sliderRate := TTSgui.AddSlider("x70 y78 w260 vRate Range-10-10 TickInterval1", IniRead("config.ini", "settings", ChosenBuff "Rate"))
		TTSgui.AddText("x10 y110", "Text:")
		editText := TTSgui.AddEdit("x10 y125 w320 h60 vSoundText", IniRead("config.ini", "settings", ChosenBuff "Text")).OnEvent("Change", (TextctrlV, *) => IniWrite(TextctrlV.Text, "config.ini", "settings", ChosenBuff "Text"))
		btnSpeak := TTSgui.AddButton("x10 y195 w320 h30", "Speak").OnEvent("Click", speak)
		btnSpeak := TTSgui.AddButton("x10 y230 w320 h30", "Set Default").OnEvent("Click", SetDefaultSound)
		sliderVol.OnEvent("Change", (*) => showSliderTooltip(sliderVol, "Vol"))
		sliderRate.OnEvent("Change", (*) => showSliderTooltip(sliderRate, "Rate"))

		hideTooltip(*) => ToolTip("")
		TTSgui.Show("w340 h270")
	}
	
	if RegExReplace(ctrl.Name, "\d+") = "HotBarTime"
		t := ctrl.Text, new := RegExReplace(t, "[^\d.]"), (new != t) && ctrl.Text := new

	if ctrl.Name = "ClipStars"
		MainGui["ClipHotkey"].enabled := ctrl.value

	for k, v in ["TrackPrecision", "TrackGMorph", "TrackBoosts", "TrackSmoothie", "TrackPMark"]
		if ctrl.Name = v
			MainGui[v "Beep"].enabled := ctrl.value

	if ctrl.Name = "TrackGuiding"
		MainGui["TrackGuidingCountDown"].enabled := ctrl.value

	if ctrl.Name = "TrackGummyStar"
		MainGui["TrackGummyStarCountDown"].enabled := ctrl.value

	if ctrl.Name = "DetectStarHoney"
		MainGui["LogHoneyPerStar"].enabled := ctrl.value

	if (InStr(ctrl.Name, "Detect") && !(ctrl.Name = "DetectStarHoney"))
		startval := ctrl.value, IniWrite(MainGui["DetectGummyStar"].value := 0, "config.ini", "settings", "DetectGummyStar"), IniWrite(MainGui["DetectScorchingStar"].value := 0, "config.ini", "settings", "DetectScorchingStar"), IniWrite(MainGui["DetectPopStar"].value := 0, "config.ini", "settings", "DetectPopStar"), MainGui[ctrl.Name].value := startval

	If (ctrl.Name ~= "StartHotkey|PauseHotkey|ReloadHotkey")
	{
		Button := StrReplace(ctrl.Name, "Hotkey") "Macro"
		hk := "~*" ctrl.value
		try Hotkey "~*" (ctrl.Name = "StartHotkey" ? StartMacro : ctrl.Name = "PauseHotkey" ? PauseMacro : ReloadMacro), "Off"
		MainGui[StrReplace(Button, "Macro") "Button"].Text := StrReplace(StrReplace(ctrl.Name, "Hotkey"), "Reload", "Stop") " (" ctrl.value ")"
		try Hotkey hk, (ctrl.Name = "StartHotkey" ? StartMacro : ctrl.Name = "PauseHotkey" ? PauseMacro : ReloadMacro), "On"
	}

	%ctrl.Name% := ctrl.value
	IniWrite(ctrl.value, "config.ini", "settings", ctrl.Name)
}
ResetHotkeys(*)
{
	global

	MacroHotkeys("Off")
	IniWrite((StartHotkey := "F1"), "config.ini", "settings", "StartHotkey")
	IniWrite((PauseHotkey := "F2"), "config.ini", "settings", "PauseHotkey")
	IniWrite((ReloadHotkey := "F3"), "config.ini", "settings", "ReloadHotkey")
	MainGui["StartHotkey"].value := "F1"
	MainGui["PauseHotkey"].value := "F2"
	MainGui["ReloadHotkey"].value := "F3"
	MainGui["StartButton"].value := "Start (F1)"
	MainGui["PauseButton"].value := "Pause (F2)"
	MainGui["ReloadButton"].value := "Stop (F3)"

	MacroHotkeys("On")
}
GetOut(*)
{
	global
	if Reloading
		Return

	GetGUIPos()
	DetectHiddenWindows 1
	CloseMiscScripts()
	try Gdip_Shutdown(pToken)
	ExitApp
}

;roblox
GetRobloxClientPos(hwnd?)
{
	global windowX, windowY, windowWidth, windowHeight
	if !IsSet(hwnd)
		hwnd := GetRobloxHWND()

	try
		WinGetClientPos &windowX, &windowY, &windowWidth, &windowHeight, "ahk_id " hwnd
	catch TargetError
		return windowX := windowY := windowWidth := windowHeight := 0
	else
		return 1
}

; Returns: hWnd = successful; 0 = window not found
GetRobloxHWND()
{
	if (hwnd := WinExist("Roblox ahk_exe RobloxPlayerBeta.exe"))
		return hwnd
	else if (WinExist("Roblox ahk_exe ApplicationFrameHost.exe"))
	{
		try
			hwnd := ControlGetHwnd("ApplicationFrameInputSinkWindow1")
		catch TargetError
			hwnd := 0
		return hwnd
	}

	else
		return 0
}

OpenRoblox(GetOffset:=0)
{
	try WinActivate GetRobloxHWND(), GetRobloxClientPos()
	(GetOffset) && YChange := GetYChange()
	Return 1
}

CloseRoblox()
{
	; if roblox exists, activate it and send Esc+L+Enter
	if (hwnd := GetRobloxHWND())
	{
		GetRobloxClientPos(hwnd)
		if (windowHeight >= 500) ; requirement for L to activate "Leave"
		{
			WinActivate "Roblox"
			SetKeyDelay 250
			send "{Esc}{L}{Enter}"
		}
		SetKeyDelay 20
		try WinClose "Roblox"
		Sleep 500
		try WinClose "Roblox"
		Sleep 4500 ;Delay to prevent Roblox Error Code 264
	}
	; kill any remnant processes
	for p in ComObjGet("winmgmts:").ExecQuery("SELECT * FROM Win32_Process WHERE Name LIKE '%Roblox%' OR CommandLine LIKE '%ROBLOXCORPORATION%'")
		ProcessClose p.ProcessID
}

Roblox()
{
	n := "Roblox ahk_exe ApplicationFrameHost.exe"
	if WinExist(n)
		return n
	n := "Roblox ahk_exe RobloxPlayerBeta.exe"
	if WinExist(n)
		return n
	return 0
}

OpenRobloxChat() => (Send("{/}"), Sleep(50), Send("{Enter}"), Sleep(100))

GetYChange()
{
	GetRobloxClientPos()
	Y := 0

	loop 3
	{
		pBMRegion := Gdip_BitmapFromScreen(windowX+windowWidth//2 "|" windowY "|100|100")
		if (Gdip_ImageSearch(pBMRegion, bmp["Pollen"],&out,,,,,2) = 1)
		{
			SplitArray := StrSplit(out, ",")
			if SplitArray.Length > 0
			{
				Y := (SplitArray[2]+4)-15
				Gdip_DisposeImage(pBMRegion)
				Break
			}
		}
		Gdip_DisposeImage(pBMRegion)
	}
	Return (Y <= 0 ? 0 : Y)
}
RunDynamicScript(script)
{
	exec := ComObject("WScript.Shell").Exec('"' A_AhkPath '" /script /force *')
	exec.StdIn.Write(script)
	exec.StdIn.Close()
	return exec
}

StartHotBarTimers()
{
	global
	exe64_Path := A_WorkingDir "\AutoHotkey.exe"
	Run('"' exe64_Path '" /script "' A_WorkingDir '\library\HotBarUser.ahk"')
}
SendKey(Key)
{
	global
	if A_IsPaused
		Return

	send "{" Key "}"
}
StopHotbars()
{
	global
	if !IsSet(HotBarSetTimers) || !Type(HotBarSetTimers) = "Array"
		HotBarSetTimers := []
		
	for _, fn in HotBarSetTimers
        SetTimer fn, 0

	loop 7
		StartedHB%A_Index% := 0
	
	HotBarSetTimers := []
}
GetPrecisionTime()
{
	global
	GetRobloxClientPos()
	YChange := GetYChange(), Time := 0

	if (PixelSearch(&OutputVarX, &OutputVarY, WindowX, WindowY+38, WindowX+windowWidth, WindowY+96, 0x8F4EB4, 0) = 1)
		Time := OutputVarY-WindowY+YChange

	TimeLeft := (Time = 0 ? 0 : (n:=Round(((96+YChange-Time)/60)*100)) > 60 ? 60 : n-(n > 20 ? 2 : 1))
	Return TimeLeft
}

GetPrecisionTime2()
{
    GetRobloxClientPos()
    YChange := GetYChange()
    Time := 0

    Loop Floor(windowWidth / 38)
	{
        if HasPrecisionColor(WindowX + (A_Index - 1) * 38, WindowY, YChange) && !HasDarkHeat(WindowX + (A_Index - 1) * 38, WindowY, YChange) {
            Time := OutputVarY - WindowY + YChange
            break
        }
	}
	
    return (Time = 0) ? 0 : (n := Round(((96 + YChange - Time) / 60) * 100)) > 60 ? 60 : n - (n > 20 ? 2 : 1)
}

HasDarkHeat(TileX, TileY, YChange) => PixelSearch(&_, &_, TileX, YChange + 38, TileX + 38, YChange + 96, 0xDB0812, 2)
HasPrecisionColor(tileX, tileY, YChange) => PixelSearch(&_, &_, tileX, tileY + 38, tileX + 38, tileY + 96, 0x8F4EB4, 0)

StarDetection(HotBars)
{
	global

	if (CheckWarnings() || (!DetectGummyStar && !DetectScorchingStar && !DetectPopStar))
		Return

	GetRobloxClientPos()
	OpenRoblox(0), Sleep(2500)

	loop
	{
		if Stopped
			Return

		GetRobloxClientPos()
		pBMRegion := Gdip_BitmapFromScreen(WindowX "|" WindowY+windowHeight-150 "|" windowWidth "|" 50)
		Result := Gdip_ImageSearch(pBMRegion, bmp[(DetectGummyStar ? "GummyStar" : "ScorchingStar")],,,,,, 15)
		Gdip_DisposeImage(pBMRegion)

		if (!Result && !A_IsPaused)
		{
			ReportStarToAlts()
			UseStarMats()

			Start := A_TickCount
			(ClipStars && Send("{" ClipHotkey "}"))
			;(DetectStarHoney) && StartHoney := GetCurrentHoney()
			loop 45 ;45s
			{
				if Stopped
					Return

				Sleep(1000)
			}
			(ClipStars && Send("{" ClipHotkey "}"))
			loop 17 ;17s
			{
				if Stopped
					Return

				Sleep(1000)
			}

			/*
			if DetectStarHoney
			{
				HoneyMade := GetCurrentHoney() - StartHoney
				Made := (n:=HoneyMade+0) >= 1e18 ? Format("{:.2f}Qi", n/1e18) : n>=1e15 ? Format("{:.2f}Qd", n/1e15) : n>=1e12 ? Format("{:.2f}T", n/1e12) : n>=1e9 ? Format("{:.2f}B", n/1e9) : n>=1e6 ? Format("{:.2f}M", n/1e6) : n>=1e3 ? Format("{:.2f}K", n/1e3) : RegExReplace(HoneyMade, "\B(?=(\d{3})+(?!\d))", ",")
				if (LogHoneyPerStar && (HoneyMade > 0))
					FileAppend("Honey Made: " Made "`n", "Star Honey.txt")
			}
			*/
		}

		sleep(1000)
	}
}

UseStarMats()
{
	global

	loop 7
		if HotBarOnStar%A_Index%
			Send("{" A_Index "}"), Sleep(50)
}

ReportStarToAlts()
{
	global

	SocketServer.GetLastError() = 0
	{
		try
		{
			for idx, _ in SocketServer.clients
				SocketServer.UseBuff(idx, "All")
		}
	}
}
CheckWarnings()
{
	global

	sendinput "{w up}{a up}{s up}{d up}"
	
	if (ClipStars && (!ClipHotkey || ClipHotkey = "None"))
	{
		MsgBox("Please Enter A Valid Clipping Hotkey!!!", , 16)
		Return 1
	}

	UI(0)
	Return 0
}
UI(mode)
{
	for k, v in ["HotBarOnStar", "HotBarTime"]
		loop 7
			MainGui[v A_Index].enabled := mode

	for k, v in ["ClipStars", "ClipHotkey", "DetectGummyStar", "DetectScorchingStar", "DetectPopStar", "Copy"]
		MainGui[v].enabled := mode

	for k, v in ["TrackPrecision", "TrackGMorph", "TrackSmoothie"]
		loop 2
			MainGui[v (A_Index = 2 ? "Beep" : "")].enabled := mode
}
EndTask(Pid)
{
	global
	DetectHiddenWindows 1
	try WinClose "ahk_class AutoHotkey ahk_pid " Pid
	DetectHiddenWindows 0
	try %Pid% := ""
}
HyperSleep(ms)
{
	static freq := (DllCall("QueryPerformanceFrequency", "Int64*", &f := 0), f)
	DllCall("QueryPerformanceCounter", "Int64*", &begin := 0)
	current := 0, finish := begin + ms * freq / 1000
	while (current < finish)
	{
		if ((finish - current) > 30000)
		{
			DllCall("Winmm.dll\timeBeginPeriod", "UInt", 1)
			DllCall("Sleep", "UInt", 1)
			DllCall("Winmm.dll\timeEndPeriod", "UInt", 1)
		}
		DllCall("QueryPerformanceCounter", "Int64*", &current)
	}
}

;general functions
UpdateMacroStatus(Message:="")
{
	global

	Color := (InStr(Message, "Disconnect") || InStr(Message, "Failed") || InStr(Message, "Error")) ? 0xFF0000
       : (InStr(Message, "Claiming") || InStr(Message, "Ready")) ? 0x228B22
       : InStr(Message, "Force") ? 0xFF4500
       : InStr(Message, "Detected") ? 0x1E90FF
       : InStr(Message, "Mondo") ? 0xA020F0
       : (InStr(Message, "Gath") || InStr(Message, "Planter") || InStr(Message, "Placing")) ? 0x00FFFF
       : InStr(Message, "Remote Control") ? 255
       : InStr(Message, "Opened") ? 0xF5F5DC
       : InStr(Message, "Pause") ? 0xFFFF00
       : InStr(Message, "Claimed") ? 0x1E90FF
       : InStr(Message, "Convert") ? 0xFFA500
       : 0xF5F5DC

	MainGui["Status"].text := Message
}
SearchForImage(NameOfFile, v:=0, aim := "fullscreen")
{
	GetRobloxClientPos()

	PosX1 := (aim = "lowright" ? windowWidth//2 : aim = "right" ? windowWidth//2 : aim = "topright" ? windowWidth//2 : aim = "hive" ? windowWidth//4 : aim = "center" ? windowWidth//4 : windowX)
	PosY1 := (aim = "low" ? windowHeight//2 : aim = "lowright" ? windowHeight//2 : aim = "lowleft" ? windowHeight//2 : aim = "hive" ? (windowHeight//4)*3 : aim = "center" ? windowHeight//4 : windowY)
	PosX2 := (aim = "lowleft" ? windowWidth//2 : aim = "left" ? windowWidth//2 : aim = "highleft" ? windowWidth//2 : aim = "inventory" ? 300 : aim = "hive" ? PosX1*3 : aim = "center" ? PosX1*3 : windowWidth)
	PosY2 := (aim = "high" ? windowHeight//2 : aim = "highleft" ? windowWidth//2 : aim = "highleft" ? windowHeight//2 : aim = "topright" ? windowHeight//2 : aim = "buff" ? 150 : aim = "abovebuff" ? 30 : aim = "center" ? PosY1*3 : windowHeight)

	if (FileExist(A_ScriptDir "\images\" NameOfFile))
	{
		result := ImageSearch(&FoundX, &FoundY, windowX + PosX1, windowY + PosY1, windowX + PosX2, windowY + PosY2, "*" v " " A_ScriptDir "\images\" NameOfFile)
		Return [result, result = 1 ? FoundX : 0, result = 1 ? FoundY : 0]
	}

	Return [0, 0, 0]
}
nowUnix() => DateDiff(A_NowUTC, "19700101000000", "Seconds")

;sockets
StartSocketConnection()
{
	global

	try SocketServer := Host(12345)
	catch as e
		Print("failed " e.Message)

	Print("started server listening: " SocketServer.addr), SocketServer.SetIdentity(0)
	SetTimer(SocketConnection, 1000)
}
SocketConnection()
{
	global SocketServer

	if SocketServer.GetLastError() != 0
	{
		Print("connection lost retrying connection...")
		try SocketServer := Host(12345)
		catch as e
			return Print("Failed to start server:" e.Message) ;log file
		Print("Started server listening: " SocketServer.addr), SocketServer.SetIdentity(0)
		UpdateMacroStatus("Status: Re-started Server")
		return 1
	}

	else
		return 1
}
GetLocalIP() {
    for iface in ComObjGet("winmgmts:").ExecQuery("Select * from Win32_NetworkAdapterConfiguration Where IPEnabled=True") {
        for ip in iface.IPAddress {
            if RegExMatch(ip, "^\d+\.\d+\.\d+\.\d+$")
                return ip
        }
    }
    return "127.0.0.1"
}
Print(msg) {
	FileAppend(msg ? msg . "`n" : "", "*")
	FileAppend(msg ? msg "`n" : "", A_ScriptDir "/logs/log.txt")
}