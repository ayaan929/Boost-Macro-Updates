#SingleInstance Force
#Requires AutoHotkey v2.0

#Warn VarUnset, Off
OnError (e, mode) => (mode = "Return") ? -1 : 0

SetWorkingDir A_ScriptDir
CoordMode "Mouse", "Screen"
CoordMode "Pixel", "Screen"
SendMode "Event"

OnMessage(0x5558, PauseScript)

GetOut(*)
{
	ExitApp
}

PauseScript(*)
{
	global
	Pause -1
}

if A_ScreenDPI != 96
{
    MsgBox(
        "Your display scaling is not set to 100% (96 DPI)." 
        . "`n`nThis script is designed to run at 100% scaling and may not work correctly."
        . "`n`nPlease set Windows display scaling to 100% and restart the script.",
        "Display Scaling Warning",
        "Icon!"
    )
}

HotBarTimers := [], HotBarTime := [], Time := A_TickCount
loop 7 {
    HotBarTimers.Push((IniRead(A_ScriptDir "\..\config.ini", "settings", "HotBarTime" A_Index))*1000)
    HotBarTime.Push(Time)
}

loop {
    loop 7 {
        if ((A_TickCount - HotBarTime[A_Index] >= HotBarTimers[A_Index]) && (HotBarTimers[A_Index] > 0))
            send("{" A_Index "}"), HotBarTime[A_Index] := A_TickCount
    }

    Sleep(25)
}