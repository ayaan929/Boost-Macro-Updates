#Include Gdip_All.ahk

bmpInit(path) {
    bmpMap := Map()
    loop files path "\*.png", "R" {
        pBitmap := Gdip_CreateBitmapFromFile(A_LoopFilePath)
        if pBitmap
            bmpMap[A_LoopFileName] := pBitmap
    }
    return bmpMap
}
