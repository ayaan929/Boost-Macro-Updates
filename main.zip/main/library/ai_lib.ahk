#Requires AutoHotkey v2
Persistent true
#Include ..\library\Gdip_All.ahk
#Include ..\library\Gdip_ImageSearch.ahk

class AI {
    __New(modelPath, dllPath, debug := false){
        this.debug := debug
        this.modelPath := modelPath
        this.dllPath := dllPath

        if !FileExist(modelPath)
            throw "Model not found: " modelPath
        if !FileExist(dllPath)
            throw "Inference dll not found: " dllPath

        this.hModule := DllCall("LoadLibrary", "Str", dllPath, "Ptr")
        if !this.hModule
            throw "LoadLibrary failed for: " dllPath

        this.pLoadModel     := this.getProc("LoadModel")
        this.pSetDebugMode  := this.getProc("SetDebugMode")
        this.pSetHomography := this.getProc("SetStudHomography")
        this.pInferenceHBmp:= this.getProc("InferenceFromHBITMAP")
        this.pInferenceRGB := this.getProc("Inference")
        this.pFreeBoxes    := this.getProc("FreeBoxes")
        this.pAnnotate     := this.getProc("Annotate")
        this.pFreeModel    := this.getProc("FreeModel")

        if !this.pLoadModel || !this.pInferenceHBmp || !this.pFreeModel
            throw "Missing required exports in inference dll"

        this.model := DllCall(this.pLoadModel
            , "WStr", modelPath
            , "IntP", &err := 0
            , "Ptr")

        if err != 0
            throw "Inference error, code: " err
        if this.model = 0
            throw "Inference error, model handle is nil"

        if this.debug && this.pSetDebugMode
            DllCall(this.pSetDebugMode, "Ptr", this.model, "Int", true)

        this.metricsBuf := Buffer(24, 0)
        this.boxSize := 32

        CreateDummyHBITMAP(width, height) {
            hdc   := DllCall("GetDC", "Ptr", 0, "Ptr")
            memDC := DllCall("CreateCompatibleDC", "Ptr", hdc, "Ptr")
            hBmp  := DllCall("CreateCompatibleBitmap", "Ptr", hdc, "Int", width, "Int", height, "Ptr")
            DllCall("SelectObject", "Ptr", memDC, "Ptr", hBmp)
            DllCall("ReleaseDC", "Ptr", 0, "Ptr", hdc)
            DllCall("DeleteDC", "Ptr", memDC)
            return hBmp
        }

        hBmp := CreateDummyHBITMAP(640, 640)
        Loop 5
            this.InferenceHBitmap(hBmp)
        DllCall("DeleteObject", "Ptr", hBmp)
    }

    getProc(name) {
        return DllCall("GetProcAddress", "Ptr", this.hModule, "AStr", name, "Ptr")
    }

    parseMetrics(buf){
        return { preprocessMs: NumGet(buf, 0,  "Float")
               , inferenceMs: NumGet(buf, 4,  "Float")
               , postMs:      NumGet(buf, 8,  "Float")
               , meanConf:    NumGet(buf, 12, "Float")
               , totalMs:     NumGet(buf, 16, "Float")
               , errorCode:   NumGet(buf, 20, "Int") }
    }

    SetHomographyPoints(studPoints, pixelPoints, hBmp := 0){
        if !this.model || studPoints.Length != pixelPoints.Length || studPoints.Length < 4
            return false
        if !this.pSetHomography
            return false

        count := 4
        refStuds := Buffer(4*2*count)
        refPixels := Buffer(4*2*count)

        Loop count {
            idx := A_Index
            NumPut("Float", studPoints[idx][1]+0, refStuds, (idx-1)*8 + 0)
            NumPut("Float", studPoints[idx][2]+0, refStuds, (idx-1)*8 + 4)
            NumPut("Float", pixelPoints[idx][1]+0, refPixels, (idx-1)*8 + 0)
            NumPut("Float", pixelPoints[idx][2]+0, refPixels, (idx-1)*8 + 4)
        }

        imgWidth := 0
        imgHeight := 0
        if hBmp {
            bmp := Buffer(24)
            if DllCall("GetObject", "Ptr", hBmp, "Int", 24, "Ptr", bmp.Ptr) {
                imgWidth := NumGet(bmp, 4, "Int")
                imgHeight := NumGet(bmp, 8, "Int")
            }
        }

        return DllCall(this.pSetHomography
            , "Ptr", this.model
            , "Ptr", refStuds.Ptr
            , "Ptr", refPixels.Ptr
            , "Int", count
            , "Int", imgWidth
            , "Int", imgHeight
            , "Int")
    }

    InferenceHBitmap(hBmp){
        out_count := 0
        if !this.pInferenceHBmp
            return { boxes: [], numBoxes: 0, metrics: this.parseMetrics(this.metricsBuf) }

        pBoxes := DllCall(this.pInferenceHBmp
            , "Ptr", this.model
            , "Ptr", hBmp
            , "IntP", &out_count
            , "Ptr", this.metricsBuf.Ptr
            , "Ptr")

        metrics := this.parseMetrics(this.metricsBuf)
        boxes := []

        if pBoxes && out_count > 0 {
            Loop out_count {
                i := A_Index - 1
                base := i * this.boxSize
                box := {}
                box.x1         := NumGet(pBoxes + base + 0,  "Float")
                box.y1         := NumGet(pBoxes + base + 4,  "Float")
                box.x2         := NumGet(pBoxes + base + 8,  "Float")
                box.y2         := NumGet(pBoxes + base + 12, "Float")
                box.confidence := NumGet(pBoxes + base + 16, "Float")
                box.class_id   := NumGet(pBoxes + base + 20, "Int")
                box.stud_dx    := NumGet(pBoxes + base + 24, "Float")
                box.stud_dy    := NumGet(pBoxes + base + 28, "Float")
                boxes.Push(box)
            }
            if this.pFreeBoxes
                DllCall(this.pFreeBoxes, "Ptr", pBoxes)
        }

        return { boxes: boxes, numBoxes: out_count, metrics: metrics }
    }

    InferenceRGB(ImageRGB, width, height) {
        out_count := 0
        if !this.pInferenceRGB
            return { boxes: [], numBoxes: 0, metrics: this.parseMetrics(this.metricsBuf) }

        pBoxes := DllCall(this.pInferenceRGB
            , "Ptr", this.model
            , "Ptr", ImageRGB
            , "Int", width
            , "Int", height
            , "IntP", &out_count
            , "Ptr", this.metricsBuf.Ptr
            , "Ptr")

        metrics := this.parseMetrics(this.metricsBuf)
        boxes := []

        if pBoxes && out_count > 0 {
            Loop out_count {
                i := A_Index - 1
                base := i * this.boxSize
                box := {}
                box.x1         := NumGet(pBoxes + base + 0,  "Float")
                box.y1         := NumGet(pBoxes + base + 4,  "Float")
                box.x2         := NumGet(pBoxes + base + 8,  "Float")
                box.y2         := NumGet(pBoxes + base + 12, "Float")
                box.confidence := NumGet(pBoxes + base + 16, "Float")
                box.class_id   := NumGet(pBoxes + base + 20, "Int")
                box.stud_dx    := NumGet(pBoxes + base + 24, "Float")
                box.stud_dy    := NumGet(pBoxes + base + 28, "Float")
                boxes.Push(box)
            }
            if this.pFreeBoxes
                DllCall(this.pFreeBoxes, "Ptr", pBoxes)
        }

        return { boxes: boxes, numBoxes: out_count, metrics: metrics }
    }

    Annotate(hBmp, outPath){
        out_box_count := 0
        if !this.pAnnotate
            return { success: 0, boxCount: 0, metrics: this.parseMetrics(this.metricsBuf), boxes: [] }

        res := DllCall(this.pAnnotate
            , "Ptr", this.model
            , "Ptr", hBmp
            , "WStr", outPath
            , "IntP", &out_box_count
            , "Ptr", this.metricsBuf.Ptr
            , "Int")

        result := this.InferenceHBitmap(hBmp)

        for box in result.boxes {
            box.stud_dx    := Round(box.stud_dx, 2)
            box.stud_dy    := Round(box.stud_dy, 2)
            box.confidence := Round(box.confidence, 3)
        }

        return { success: res, boxCount: out_box_count, metrics: result.metrics, boxes: result.boxes }
    }

    close(){
        if this.model {
            if this.pFreeModel
                DllCall(this.pFreeModel, "Ptr", this.model)
            this.model := 0
        }
        if this.hModule {
            DllCall("FreeLibrary", "Ptr", this.hModule)
            this.hModule := 0
        }
    }
}
